# GSAP patterns for ad units

## Canvas sequence driven by GSAP

This replaces an Animate CC movie clip: GSAP tweens a frame index and the canvas draws that frame. The sequence can then sit on the main timeline, be scrubbed, reversed, or tied to input.

```js
const seq = { frame: 0 };
const frames = [];               // preloaded Image objects, or one sprite sheet
const ctx = canvas.getContext("2d");

function draw() {
  const i = Math.round(seq.frame);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(frames[i], 0, 0, canvas.width, canvas.height);
  // sprite sheet: drawImage(sheet, sx, sy, cw, ch, 0, 0, w, h)
}

const tl = gsap.timeline({ paused: true });
tl.to(seq, { frame: frames.length - 1, duration: frames.length / 12, ease: "none", onUpdate: draw });
```

- Use `ease: "none"` for real-time playback. Other eases give slow-in or slow-out on the footage itself.
- Size the canvas for devicePixelRatio, but cap it. Retina doubles memory.
- Several elements: one tween per element, all on one timeline.

## Local preview per Cr.ED module

The preview mimics what the platform will do, so the team can judge timing before upload. It is a phone-sized frame (390 wide) with dummy article text above and below the ad slot.

- **Immersion**: the slot pins while the reader scrolls. ScrollTrigger with `scrub` drives `seq.frame` over the scroll range set by 互動完成距離 (screen heights) and 播完序列圖的時間區段 (start and end %). Mirror those two form values so the preview matches the upload.
- **Story / 文中鎖屏**: swipe between pages. Map the pointer delta with `gsap-plugins` Observer, and snap per page.
- **Action / 置底**: a fixed bottom bar, 640x320 scaled to the frame width.
- Gyro and other interactions are not offered by the Cr.ED modules, so the preview leaves them out.

## Shared timeline (ad + hyperframes video)

To render the 5 s / 15 s MP4 from the same creative:
- Build the timeline in a function that returns it paused: `buildTimeline(tl)`.
- The ad calls `.play()`, plus interaction. hyperframes registers it on `window.__timelines` and seeks it.
- Inside that function: no timers, no `repeat: -1`, no `Math.random()` without a seed, no reading of pointer or scroll state. Keep loops and interaction outside, in the ad wrapper only.
- Footage elements: in the ad they are canvas sequences; in hyperframes the original clip can be a `<video>` element instead, if it looks better.

## Performance
- Preload all frames before starting the timeline. Show the first frame or the backup image meanwhile.
- Animate `transform` and `opacity` only on DOM layers.
- Test on a mid-range Android phone, not only desktop Chrome.
