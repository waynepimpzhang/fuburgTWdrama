# Asset pipeline: Kling / Seedance footage to ad elements

Footage becomes an ad element in one of three ways. Pick by what the element has to do:

| Route | Use when | Output |
|---|---|---|
| **Image sequence** | The element must be scrubbed, reversed, paused on a frame, or tied to scroll / drag / timeline | WebP or JPG frames, or a sprite sheet, drawn to `<canvas>` |
| **Green-screen cut-out** | The element sits over other layers or the page and must move or react on its own | Keyed frames with alpha (sequence or sprite sheet), or alpha video |
| **Plain `<video>`** | It only plays straight through, full-frame | H.264 MP4 (plus WebM if the spec allows) |

These can be combined: a keyed cut-out can also be a sequence.

## Generating footage that keys and loops well
<!-- TODO: confirm with the user's Kling / Seedance experience -->
- Ask for a flat, evenly lit chroma green (or blue when the subject is green) background. Avoid green spill on the subject, motion blur and hair against the background.
- Keep the camera locked when the element is a cut-out. A moving background cannot be keyed cleanly.
- For loops, use first-and-last-frame generation with the same frame.

## 1. Extract frames

```bash
# pick fps by budget: 12–15 fps is usually enough for ads
ffmpeg -i in.mp4 -vf "fps=12,scale=600:-1:flags=lanczos" frames/f_%03d.png
```

Trim to the useful range first (`-ss`, `-t`). Frame count × frame weight is the main cost of the whole unit.

## 2. Key green (cut-outs only)

```bash
ffmpeg -i in.mp4 -vf "fps=12,scale=600:-1,chromakey=0x00FF00:0.12:0.08,despill=type=green" frames/k_%03d.png
```

- `similarity` / `blend` (0.12 / 0.08) are starting points. Tune them per clip and check edges on both a dark and a light background.
- Sample the real background colour from a frame instead of assuming `0x00FF00`.
- <!-- TODO: if ffmpeg keying is not clean enough, decide on the fallback (ComfyUI background-removal / matting model, After Effects Keylight, or a Higgsfield / Firefly background removal step) -->

## 3. Pack and compress

- **Sprite sheet** (fewer requests, one decode): pack frames into a grid and record the cell size and count in a JSON file next to it. <!-- TODO: script scripts/pack_sprites.py -->
- **Separate numbered frames**: what Cr.ED Immersion takes, zipped per 素材.
- Formats: WebP for everything that needs alpha. JPG for opaque sequences if the spec or target browsers reject WebP. Never PNG in the shipped unit unless the spec demands it.
- Alpha video: WebM VP9 alpha works in Chrome and Firefox. Safari needs HEVC with alpha, so a keyed **sequence** is the safer default for ads.

```bash
# frames to WebP with ffmpeg's libwebp (cwebp is not installed); alpha is kept
ffmpeg -i frames/k_%03d.png -c:v libwebp -quality 75 -lossless 0 frames/k_%03d.webp
```

## 4. Budget check
- Each frame and each zip against the limits from `check_assets.py --spec <id>` (Immersion: frames under 150KB, one zip under 20MB per 素材).
- If over budget, in this order: lower fps → lower quality → shorten the sequence → split into two 素材 layers. Keep the width at the placement width.
