# HTML5 output for Cr.ED's Adobe Animate format

In the Motion parent form, 上傳格式 = **Adobe Animate** shows an **Animate Zip** field: one `.zip` with exactly one `.html` at its root (name it `index.html`). The form's **width / height** set the placement size (640 x 1386 全屏, 640 x 1280 文中); build the canvas at that size. The other Motion fields are in `cred-ad-upload/references/ui.md` § Motion 上傳格式. Animate CC used to export this page. Here it is built by hand around the shared GSAP timeline, keeping the same contract with the platform.

Size limit depends on the parent version (user, 2026-11-12):

| Parent | Limit | When |
|---|---|---|
| Motion **v1.3.1** (the 「Motion」 card on the build page) | **2MB** | default for new ads |
| Motion-魔動星軌 **v1.2.9** | 10MB | older ads; check with `--motion 1.2.9` |

Ask which parent the ad goes into before building. Plan for 2MB unless the user says v1.2.9.

**Entry file and playback.** The platform takes the one `.html` at the zip root, adds a `<base href>` pointing at the unzipped folder, and plays it in an iframe. The reference case's entry is `<Animate 專案名>.html` (Animate's project name) and plays, so the name itself does not affect playback. What does: exactly one root `.html`, and every asset path relative to it. Name it `index.html` anyway; that is the convention and was not seen failing on v1.3.1.

Reference case, read 2026-11-12: an existing client ad (Motion-魔動星軌 v1.2.9, 640 x 1386). It is an Animate CC export.

## The platform contract: motionSet

Clicks do not live inside the creative. They are **互動按鈕** (interaction buttons) that Motion draws over the canvas. The creative only shows and hides them by name, through one function the page defines:

```html
<script>
var motionSet;
(function () {
  var inFrame = !!window.frameElement;
  var wt = window.parent;
  motionSet = function (name, action) {          // action: "show" | "hide"
    if (inFrame) wt.AD2CrazyAnCC(name, action);  // Motion's bridge
    else console.log(name, action);              // local preview
  };
})();
</script>
```

The timeline calls `motionSet` at the moments a button or overlay should appear. In the reference case:
- frame 0: `motionSet("video","hide"); motionSet("p1_click_through","show"); motionSet("p2_click_through","hide"); motionSet("image","hide")`
- frame 203: video, `p2_click_through` and image show; `p1_click_through` hides

In GSAP, put these calls on the shared timeline with `tl.call(motionSet, ["p1_click_through", "show"], 0)`. Calls are deterministic, so the hyperframes render can keep them; there they only log.

## Interaction buttons (set in the Motion form, not in the zip)

Each 新增互動按鈕 has:
- 直接顯示 (show without waiting for `motionSet`). Even then the 互動按鈕對應名字 must be filled, or the report is wrong.
- **互動按鈕對應名字**: the name `motionSet` uses. A button that opens the landing page is named `…_click_through` (for example `p1_click_through`), so the report counts its clicks (user, 2026-11-12).
- 階層 (higher is on top); width, height, left, top in **vw**; rotation in deg.
- 開啟外連 + **url**: the landing page lives here, never in the creative.
- 開啟音效, 開啟影片, 使用圖片: a button can also be a sound toggle, a video player or an image. In the reference case a button named `video` (100vw x 57vw at top 47vw, 階層 5) plays the video, and the creative shows it with `motionSet("video","show")`.

Reference values: two click buttons covering the whole ad (100vw x 300vw at 0,0, 階層 3), one per scene, swapped by `motionSet` so each scene can link elsewhere.

When handing over a build, list every `motionSet` name the creative uses, with the button fields each one needs (size and position in vw, url or video). The person filling the Motion form copies them from that list.

## Libraries

The reference HTML loads CreateJS from `code.createjs.com`, and the platform swapped it for its own copy on `content.ad2iction.com`. So external scripts do load, but nothing shows the platform accepts a GSAP CDN. **Pack `gsap.min.js` in the zip** (about 70KB of the 2MB).

## The 2MB budget (v1.3.1)

Everything ships inside 2MB: GSAP, the page, and every frame and still. Footage is the cost:

- A 640x1386 WebP frame at quality 70 is about 15–20KB, so a full-screen sequence fits roughly 80–100 frames once the other files are counted. A 640x320 frame is a few KB.
- Video can go to an interaction button with 開啟影片 instead, outside the zip (the reference case does this). Then the zip only carries the animated layers around it.
- Over budget, in this order: fewer frames (12 fps is usually enough) → lower WebP quality → animate only the part that moves (a keyed cut-out over one still) → move footage into a 開啟影片 button.

## Page structure

```
index.html          motionSet bridge, canvas at the form's width x height, scaled to the slot width with CSS
js/gsap.min.js      packed locally
js/creative.js      buildTimeline(tl) from gsap-ad-patterns.md, motionSet calls, canvas draw loop
img/                frames and stills, WebP or JPG, numbered
```

- All paths relative.
- The canvas backing size is the form's width x height. Cap devicePixelRatio scaling at 2×.
- Preload every frame, then start the timeline. Until then, show the first frame.
- No URLs and no click handlers in the creative. Clicks are interaction buttons.
- Muted by default.

## Package and check

- Zip the folder contents, not the folder, so `index.html` sits at the zip root. Keep it the only `.html` at the root.
- Put the zip in `<project>/cred/<id>/v<N>/animate/` and run `python ~/.claude/skills/cred-ad-upload/scripts/check_assets.py <id> <folder>`. It fails over the limit (2MB, or 10MB with `--motion 1.2.9`) or without exactly one root `.html`, and warns on a name other than `index.html` and on external URLs.
- Open `index.html` from the unzipped copy in a phone-sized window. The console should log each `motionSet` call at the right moment.
