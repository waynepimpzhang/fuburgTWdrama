---
name: html5-ad-unit
description: Compose ad creatives from Kling or Seedance footage with GSAP, for the team's Cr.ED placements. One timeline gives two outputs, an MP4 rendered with hyperframes or an HTML5 canvas zip for Cr.ED's Adobe Animate format (2MB on Motion v1.3.1, 10MB on v1.2.9) (the replacement for Animate CC). Also makes image sequences, green-screen cut-outs and local preview pages. Use whenever footage must be combined with key visuals, text or logo, animated, or turned into 序列圖 / 去背元件 / an HTML5 or Animate CC zip, or when the user wants a 測試頁 / 本機預覽 of an ad. Placement limits come from cred-ad-upload.
---

# Ad creative from footage

The placements are the 15 Cr.ED placements in `cred-ad-upload`, which owns their sizes, weights and upload. Each placement takes either media (video / images / sequence zip) or, with the Motion **Adobe Animate** format, an HTML5 zip (2MB on Motion v1.3.1, 10MB on Motion-魔動星軌 v1.2.9). This skill makes the creative for either. When footage only needs a crop or a re-encode, skip this skill: `cred-ad-upload` handles that directly.

## Work loop

1. **Get the limits and pick the output.** Run `python ~/.claude/skills/cred-ad-upload/scripts/check_assets.py --spec <id>`. With the user, pick the output for this placement:
   - **media**: the composed result is an MP4, images or a sequence zip that go into the placement's components.
   - **html**: the composed result is an HTML5 canvas zip for the Adobe Animate format (2MB on v1.3.1, 10MB on v1.2.9).
   Done when the output is chosen and every footage clip, image and text line has a place in it.
2. **Make the elements** from footage: sequence, green-screen cut-out, or plain video. See `references/asset-pipeline.md`.
3. **Build one GSAP timeline** for the creative, using `buildTimeline(tl)` from `references/gsap-ad-patterns.md` § Shared timeline. That function is the only place the animation lives, so both outputs stay identical.
4. **Render the chosen output:**
   - media → hyperframes renders the timeline to MP4 at the component's size. Write it into cred-ad-upload's folder layout `<project>/cred/<id>/v<N>/<component>/`. For Immersion, turn the MP4 into a sequence zip (`asset-pipeline.md` § 1, § 3).
   - html → wrap the timeline in a canvas page and package it. See `references/html5-output.md`.
5. **Preview locally** before upload when the user wants to see it: `preview.html` that plays the result the way the placement does. See `references/gsap-ad-patterns.md` § Local preview. It never touches Cr.ED.
6. **Hand back to cred-ad-upload** for `check_assets.py <id> <folder>` (media, or the zip in `animate/`) and the upload.

## Rules

- Output folders count upward (`v1`, `v2` …). Never overwrite an earlier version.
- Sizes and weights come from step 1 every time, never from memory.
- Auto-playing video is muted. Sound starts only on a user action.

## Files

| File | What it holds |
|---|---|
| `references/asset-pipeline.md` | Footage to sequence, keyed alpha, compression, budget check |
| `references/gsap-ad-patterns.md` | Canvas sequence driven by GSAP, local preview per module, shared timeline with hyperframes |
| `references/html5-output.md` | The Adobe Animate format: size limit per Motion version, entry file, motionSet and interaction buttons, packaging |
