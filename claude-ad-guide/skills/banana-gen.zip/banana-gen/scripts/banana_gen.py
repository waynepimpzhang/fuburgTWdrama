"""Generate images on Macro Banana (<公司內部生圖站>) and save them to chosen paths.

Drives <公司內部生圖站>/studio with Playwright and the installed Chrome, using a
dedicated, persistent Chrome profile that stays signed in with Google.

  python banana_gen.py login
  python banana_gen.py options
  python banana_gen.py one --model nbpro --prompt "..." --out a.png [--aspect 16:9] [--res 2K] [--ref x.jpg]
  python banana_gen.py run jobs.csv [--only id1,id2] [--dry-run]

jobs.csv columns: id,model,prompt,out,aspect,res,refs
  refs: reference image paths separated by ';'. Relative paths resolve
  against the CSV's folder. Each run appends to banana_log.tsv next to it.
"""
import argparse
import csv
import datetime as dt
import os
import re
import sys
from pathlib import Path

from playwright.sync_api import TimeoutError as PWTimeout
from playwright.sync_api import sync_playwright

URL = os.environ.get("BANANA_STUDIO_URL") or sys.exit("Set BANANA_STUDIO_URL to the studio page URL (ask the team)")
PROFILE = Path(os.environ.get("BANANA_PROFILE", Path.home() / ".banana-gen" / "profile"))

# Aliases -> exact labels in Macro Banana's model menu (checked 2026-11-03).
MODELS = {
    "nbpro": "Nano Banana Pro",
    "nb2": "Nano Banana 2",
    "gpt2": "GPT Image 2",
}

GEN_TIMEOUT_MS = 6 * 60 * 1000


def resolve_model(name):
    if name in MODELS:
        return MODELS[name]
    if name in MODELS.values():
        return name
    sys.exit(f"Unknown model '{name}'. Use one of: {', '.join(f'{k} ({v})' for k, v in MODELS.items())}")


def open_context(p, headless=False):
    PROFILE.mkdir(parents=True, exist_ok=True)
    # Google sign-in refuses browsers that announce automation.
    return p.chromium.launch_persistent_context(
        str(PROFILE),
        channel="chrome",
        headless=headless,
        accept_downloads=True,
        viewport={"width": 1400, "height": 900},
        ignore_default_args=["--enable-automation"],
        args=["--disable-blink-features=AutomationControlled"],
    )


def cmd_login(_args):
    with sync_playwright() as p:
        ctx = open_context(p)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto(URL)
        print("Sign in with Google in the opened window, then close the window.")
        page.wait_for_event("close", timeout=0)
        ctx.close()


def open_studio(page):
    page.goto(URL, wait_until="load", timeout=60000)
    gen = page.get_by_role("button", name="GENERATE")
    signin = page.get_by_role("button", name=re.compile("Sign in with Google"))
    gen.or_(signin).first.wait_for(timeout=60000)
    if signin.count():
        raise RuntimeError("Not logged in. Run: python banana_gen.py login")
    return gen


def pills(page):
    """The setting chips under the prompt box: model, aspect, search, resolution.
    圖生圖 mode has no search chip, so resolution is always the last one."""
    panel = page.locator("div.rounded-2xl", has=page.locator("textarea")).last
    return panel.locator("div.relative > div.cursor-pointer")


def menu_items(pill):
    """Open a chip's menu and return its option buttons (first text line = the label)."""
    pill.click()
    menu = pill.locator("xpath=following-sibling::div[1]")
    menu.wait_for(timeout=5000)
    return menu.get_by_role("button")


def close_menu(page):
    page.keyboard.press("Escape")
    page.mouse.click(5, 5)
    page.wait_for_timeout(300)


def pick(page, index, value, what):
    chips = pills(page)
    if index < 0:
        index += chips.count()
    pill = chips.nth(index)
    if pill.inner_text().strip() == value:
        return
    items = menu_items(pill)
    labels = [t.split("\n")[0].strip() for t in items.all_inner_texts()]
    # An unavailable model carries a warning sign after its name ("GPT Image 2 ⚠").
    match = [i for i, l in enumerate(labels) if l == value or l.startswith(value + " ")]
    if not match:
        close_menu(page)
        raise RuntimeError(f"No {what} option {value!r}. Options: {labels}")
    item = items.nth(match[0])
    if "cursor-not-allowed" in (item.get_attribute("class") or ""):
        hint = item.get_attribute("title") or "disabled"
        close_menu(page)
        raise RuntimeError(f"{what} {value!r} is not available right now: {hint}")
    item.click()
    page.wait_for_timeout(500)
    if pills(page).nth(index).inner_text().strip() != value:
        raise RuntimeError(f"Could not set {what} to {value!r}")


def set_count_to_one(page):
    """The 1/4 counter sets how many images one click makes; keep it at 1."""
    counter = page.get_by_text(re.compile(r"^\d/4$"))
    minus = page.get_by_role("button", name="−")
    for _ in range(4):
        if counter.inner_text().startswith("1/"):
            return
        minus.click()
        page.wait_for_timeout(200)


def task_ids(page):
    """Task IDs of the gallery images, newest first. File names carry them:
    .../images%2F<user>%2Fnb-<epoch ms>-<suffix>.jpg"""
    ids = []
    for img in page.locator("main img[src*='firebasestorage']").all():
        m = re.search(r"%2F([a-z]+-(\d{13})-\w+)\.", img.get_attribute("src") or "")
        if m:
            ids.append((m.group(1), int(m.group(2)), img))
    return ids


def new_result(page, before, since_ms):
    """The first gallery image that wasn't there before the click and was made after it."""
    for task, ms, img in task_ids(page):
        if task not in before and ms >= since_ms:
            return task, img
    return None


def generate(page, model, prompt, out, aspect=None, res=None, refs=()):
    gen = open_studio(page)

    mode = "@ 圖生圖 提示詞中包含參考圖" if refs else "✦ 文字生成圖片 僅提示詞"
    page.get_by_role("button", name=mode).click()
    page.wait_for_timeout(500)

    pick(page, 0, model, "model")
    if aspect:
        pick(page, 1, aspect, "aspect")
    if res:
        pick(page, -1, res, "resolution")
    set_count_to_one(page)

    if refs:
        page.locator("input[type=file]").first.set_input_files([str(r) for r in refs])
        used = page.get_by_text(re.compile(rf"^{len(refs)} / \d+ used$"))
        try:
            used.wait_for(state="attached", timeout=60000)
        except PWTimeout:
            raise RuntimeError(f"Reference upload not confirmed ({len(refs)} file(s))")

    page.locator("textarea").first.fill(prompt)
    page.locator("main img[src*='firebasestorage']").first.wait_for(timeout=30000)
    before = {t for t, _, _ in task_ids(page)}
    # The time check allows for clock skew between this computer and the server.
    since_ms = int(dt.datetime.now().timestamp() * 1000) - 60000
    gen.click()

    deadline = dt.datetime.now() + dt.timedelta(milliseconds=GEN_TIMEOUT_MS)
    while not (found := new_result(page, before, since_ms)):
        if dt.datetime.now() > deadline:
            shot = Path(out).with_suffix(".error.png")
            page.screenshot(path=str(shot))
            raise RuntimeError(f"No result within {GEN_TIMEOUT_MS // 60000} min; screenshot: {shot}")
        page.wait_for_timeout(2000)
    task, img = found
    page.wait_for_timeout(1500)

    # Open the result's details and use its 下載 button for the full-size file.
    # The card's hover overlay covers the image, so force the click through it.
    img.click(force=True)
    page.get_by_text("生成詳情").wait_for(timeout=15000)
    with page.expect_download(timeout=120000) as dl:
        page.get_by_role("button", name="下載").click()
    d = dl.value
    out = Path(out)
    if not out.suffix:
        out = out.with_suffix(Path(d.suggested_filename).suffix or ".png")
    out.parent.mkdir(parents=True, exist_ok=True)
    d.save_as(str(out))
    check_output(out, aspect)
    return out, task


_seen_hashes = {}


def check_output(out, aspect):
    """Catch a download of the wrong result: duplicate of an earlier file, or wrong shape."""
    import hashlib
    from PIL import Image
    digest = hashlib.md5(out.read_bytes()).hexdigest()
    if digest in _seen_hashes:
        raise RuntimeError(f"Downloaded file is identical to {_seen_hashes[digest]} (stale result)")
    _seen_hashes[digest] = out.name
    if aspect:
        w, h = map(float, aspect.split(":"))
        with Image.open(out) as im:
            got = im.width / im.height
        if abs(got - w / h) / (w / h) > 0.05:
            raise RuntimeError(f"Image is {im.width}x{im.height}, not {aspect} (wrong result?)")


def cmd_options(args):
    """Print the choices in each setting menu."""
    with sync_playwright() as p:
        ctx = open_context(p, args.headless)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        open_studio(page)
        if args.model:
            pick(page, 0, resolve_model(args.model), "model")
        for i, name in enumerate(["model", "aspect", "search", "resolution"][:pills(page).count()]):
            items = menu_items(pills(page).nth(i))
            labels = []
            for item in items.all():
                label = item.inner_text().split("\n")[0].strip()
                if "cursor-not-allowed" in (item.get_attribute("class") or ""):
                    label += f" (unavailable: {item.get_attribute('title') or 'disabled'})"
                labels.append(label)
            print(f"{name}: {labels}")
            close_menu(page)
        ctx.close()


def log_row(log_path, row):
    new = not log_path.exists()
    with open(log_path, "a", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        if new:
            w.writerow(["time", "id", "model", "res", "status", "out", "task", "prompt"])
        w.writerow(row)


def run_jobs(jobs, log_path, headless):
    failed = 0
    with sync_playwright() as p:
        for j in jobs:
            ctx = open_context(p, headless)
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            now = dt.datetime.now().isoformat(timespec="seconds")
            try:
                out, task = generate(page, j["model"], j["prompt"], j["out"],
                                     j.get("aspect"), j.get("res"), j.get("refs", ()))
                print(f"OK   {j['id']}  {j['model']}  task={task}  -> {out}")
                log_row(log_path, [now, j["id"], j["model"], j.get("res") or "", "ok", out, task, j["prompt"]])
            except Exception as e:
                failed += 1
                print(f"FAIL {j['id']}  {j['model']}  {e}")
                log_row(log_path, [now, j["id"], j["model"], j.get("res") or "", "fail: " + str(e).splitlines()[0], j["out"], "", j["prompt"]])
            ctx.close()
    return failed


def cmd_one(args):
    out = Path(args.out).resolve()
    job = {"id": out.stem, "model": resolve_model(args.model), "prompt": args.prompt, "out": out,
           "aspect": args.aspect, "res": args.res,
           "refs": [Path(r).resolve() for r in args.ref or []]}
    sys.exit(1 if run_jobs([job], out.parent / "banana_log.tsv", args.headless) else 0)


def cmd_run(args):
    csv_path = Path(args.csv).resolve()
    base = csv_path.parent
    only = set(args.only.split(",")) if args.only else None
    jobs = []
    with open(csv_path, encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            if not (r.get("id") or "").strip() or (only and r["id"] not in only):
                continue
            refs = [base / x.strip() for x in (r.get("refs") or "").split(";") if x.strip()]
            for ref in refs:
                if not ref.exists():
                    sys.exit(f"{r['id']}: reference not found: {ref}")
            jobs.append({"id": r["id"], "model": resolve_model((r.get("model") or "nbpro").strip()),
                         "prompt": r["prompt"].strip(), "out": base / r["out"].strip(),
                         "aspect": (r.get("aspect") or "").strip() or None,
                         "res": (r.get("res") or "").strip() or None, "refs": refs})
    if not jobs:
        sys.exit("No jobs selected.")
    for j in jobs:
        print(f"{j['id']}: {j['model']} -> {j['out']}" + (f"  refs={len(j['refs'])}" if j["refs"] else ""))
    if args.dry_run:
        return
    sys.exit(1 if run_jobs(jobs, base / "banana_log.tsv", args.headless) else 0)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("login").set_defaults(fn=cmd_login)
    s = sub.add_parser("options", help="list the choices in each setting menu")
    s.add_argument("--model", help="switch to this model first")
    s.add_argument("--headless", action="store_true")
    s.set_defaults(fn=cmd_options)
    for name, fn in (("one", cmd_one), ("run", cmd_run)):
        s = sub.add_parser(name)
        s.set_defaults(fn=fn)
        s.add_argument("--headless", action="store_true", help="hide the browser")
        if name == "one":
            s.add_argument("--model", default="nbpro")
            s.add_argument("--prompt", required=True)
            s.add_argument("--out", required=True)
            s.add_argument("--aspect")
            s.add_argument("--res", help="512, 1K, 2K or 4K")
            s.add_argument("--ref", action="append")
        else:
            s.add_argument("csv")
            s.add_argument("--only", help="comma-separated job ids")
            s.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
