---
name: banana-gen
description: Generate images on Macro Banana (<公司內部生圖站>, the team's "大香蕉" studio) with Nano Banana Pro or Nano Banana 2 through a Playwright script, and save each result to a chosen path. Use whenever the user says to generate images "用大香蕉", with Macro Banana, or on <公司內部生圖站>, including batch generation from a prompt list and image-to-image with reference pictures. Do not drive the site by hand through a browser MCP; this script costs far fewer tokens.
---

# Macro Banana (大香蕉) image generation

The script `scripts/banana_gen.py` (next to this file) opens <公司內部生圖站>/studio in the installed Chrome with its own persistent profile (`~/.banana-gen/profile`, signed in with Google), sets the model, aspect and resolution, fills the prompt, clicks GENERATE, and downloads the new result from its 生成詳情 panel.

Default model is Nano Banana Pro (`nbpro`); use Nano Banana 2 (`nb2`) when the user asks for it, for the extra-wide/tall ratios, or for 512 drafts. The site shows no per-image cost. Generating still uses the team's quota, so confirm the job list with the user before a batch; `--dry-run` and `options` generate nothing.

## Models and choices (checked 2026-11-03; re-check with `options --model <alias>`)

| alias | site label | aspect (`--aspect`) | resolution (`--res`) |
|---|---|---|---|
| `nbpro` (default) | Nano Banana Pro | 1:1 2:3 3:2 3:4 4:3 4:5 5:4 9:16 16:9 21:9 | 1K 2K 4K |
| `nb2` | Nano Banana 2 | nbpro's list plus 1:4 4:1 1:8 8:1 | 512 1K 2K 4K |
| `gpt2` | GPT Image 2 | | currently disabled on the site (OpenRouter 額度不足) |

Empty aspect/resolution keep whatever the site last used, so pass them explicitly. The script always sets the image count to 1 and leaves Google Search grounding as it is (Off by default).

## Commands

```
python <skill>/scripts/banana_gen.py login                       # opens the site; the user signs in with Google, then closes the window
python <skill>/scripts/banana_gen.py options [--model nb2]       # menu choices, free
python <skill>/scripts/banana_gen.py one --prompt "..." --out path/name.png [--model nbpro] [--aspect 16:9] [--res 2K] [--ref img.jpg]
python <skill>/scripts/banana_gen.py run jobs.csv [--only id1,id2] [--dry-run]
```

`jobs.csv` (UTF-8, header row): `id,model,prompt,out,aspect,res,refs`. Empty `model` means `nbpro`. `out` and `refs` are relative to the CSV's folder; `refs` holds reference images separated by `;` (the site takes up to 14, 20 MB each). With refs the script switches to 圖生圖 mode; refer to them in the prompt as `@image1`, `@image2`, … or "Image 1 is …".

On Windows set `PYTHONIOENCODING=utf-8` so the console can print the site's labels.

Each job gets a fresh browser launch. The script records the gallery's task IDs before clicking GENERATE and downloads only an image whose task ID is new, then fails the job if the file duplicates an earlier one in the run or its shape doesn't match `aspect`.

Each run appends one row per job to `banana_log.tsv` beside the CSV (or beside `--out`): time, id, model, resolution, ok/fail, output path, task ID, prompt. Exit code is 1 if any job failed.

## After a run

- Read the log, then look at each output image and check every character of any text in it; models still miswrite Chinese. Report wrong characters instead of calling the job done.
- Every result also stays in the user's Macro Banana gallery.
- Only one script run at a time: the Chrome profile is locked while the window is open.

## When it fails

- `Not logged in` → tell the user they need to sign in, then run `login` in the background; they sign in with Google in the window that opens and close it. Don't retry generation until they have.
- `... is not available right now: <reason>` → the site disabled that model (for example GPT Image 2 when OpenRouter credit runs out); use `nbpro` or `nb2`.
- `No ... option` → the error lists what the site offers; fix the value or the `MODELS` table.
- Timeout → a `.error.png` screenshot sits next to the intended output; look at it.
- After a site redesign, the selectors in `pills()`, `pick()` and `generate()` may need updating. Setting chips sit under the prompt box in the order model, aspect, search, resolution; 圖生圖 mode drops the search chip.
