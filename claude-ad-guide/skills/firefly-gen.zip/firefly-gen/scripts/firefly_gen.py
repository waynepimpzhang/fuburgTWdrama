"""Generate images in Adobe Firefly's web UI and save them to chosen paths.

Drives firefly.adobe.com/image-generate (the 2026-11 redesign) with Playwright
and the installed Chrome, using a dedicated, persistent Chrome profile that
stays logged in.

  python firefly_gen.py login
  python firefly_gen.py options --model nbpro
  python firefly_gen.py one --model flare --prompt "..." --out a.png [--aspect 16:9] [--quality 2K] [--ref x.jpg]
  python firefly_gen.py run jobs.csv [--only id1,id2] [--dry-run]
  python firefly_gen.py fetch --out a.png [--label "..."]   # download the newest (or a named) result, free

jobs.csv columns: id,model,prompt,out,aspect,quality,refs
  refs: reference image paths separated by ';'. Relative paths resolve
  against the CSV's folder. Each run appends to firefly_log.tsv next to it.
"""
import argparse
import csv
import datetime as dt
import os
import re
import sys
from pathlib import Path

from playwright.sync_api import TimeoutError as PWTimeout
from playwright.sync_api import sync_playwright

URL = "https://firefly.adobe.com/image-generate"
PROFILE = Path(os.environ.get("FIREFLY_PROFILE", Path.home() / ".firefly-gen" / "profile"))

# Aliases -> exact option labels in the 模型 picker (checked 2026-11-13).
MODELS = {
    "gpt2": "GPT Image 2",
    "flare": "GPT Image 2.6 Flare",
    "sunburst": "GPT Image 2.6 Sunburst",
    "flare25": "GPT Image 2.5 Flare",
    "sunburst25": "GPT Image 2.5 Sunburst",
    "nbpro": "Gemini 3.0 (Nano Banana Pro)",
    "nb2": "Gemini 3.1 (Nano Banana 2)",
    "nb21": "Gemini Nano Banana 2.1",
    "ff5": "Firefly Image 5",
}

GEN_TIMEOUT_MS = 6 * 60 * 1000
# Pickers in the 生成式設定 popover. GPT Image 2 has 品質 (低/中/高); the others have 解析度.
SEL_MODEL = "[data-testid=ugi-model-picker]"
SEL_ASPECT = "[data-testid=ugi-aspect-ratio-picker]"
SEL_QUALITY = '[data-testid=ugi-resolution-picker], sp-picker[aria-label="品質"], sp-picker[aria-label="Quality"]'
SEL_THUMB = "firefly-media-strip-thumbnail button[aria-label]"


def resolve_model(name):
    if name in MODELS:
        return MODELS[name]
    if name in MODELS.values():
        return name
    sys.exit(f"Unknown model '{name}'. Use one of: {', '.join(f'{k} ({v})' for k, v in MODELS.items())}")


def open_context(p, headless=False):
    PROFILE.mkdir(parents=True, exist_ok=True)
    return p.chromium.launch_persistent_context(
        str(PROFILE),
        channel="chrome",
        headless=headless,
        accept_downloads=True,
        viewport={"width": 1400, "height": 900},
    )


def cmd_login(_args):
    with sync_playwright() as p:
        ctx = open_context(p)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto(URL)
        print("Log in to Adobe in the opened window, then close the window.")
        page.wait_for_event("close", timeout=0)
        ctx.close()


def clean(t):
    return t.replace("​", "").strip()  # the UI puts zero-width spaces inside labels


def open_page(page):
    page.goto(URL, timeout=90000, wait_until="domcontentloaded")
    box = page.get_by_test_id("ugi-prompt-input").get_by_role("textbox")
    try:
        box.wait_for(timeout=60000)
    except PWTimeout:
        if page.get_by_role("button", name=re.compile(r"^(登入|Sign in)$")).count():
            raise RuntimeError("Not logged in. Run: python firefly_gen.py login")
        raise
    page.wait_for_timeout(2000)
    return box


def open_settings(page):
    """The 生成式設定 popover closes after some picks; reopen it when needed."""
    if not page.locator(SEL_MODEL).first.is_visible():
        page.get_by_test_id("ugi-generative-settings-button").click()
        page.locator(SEL_MODEL).first.wait_for(timeout=10000)
        page.wait_for_timeout(500)


def pick(page, selector, option_pattern, what):
    open_settings(page)
    picker = page.locator(selector)
    if not picker.count() or not picker.first.is_visible():
        raise RuntimeError(f"This model has no {what} setting")
    picker.first.click()
    page.wait_for_timeout(800)
    opts = page.get_by_role("option")
    for i in range(opts.count()):
        if option_pattern.search(clean(opts.nth(i).inner_text())):
            opts.nth(i).click()
            page.wait_for_timeout(1200)
            return
    labels = [clean(t) for t in opts.all_inner_texts()]
    page.keyboard.press("Escape")
    raise RuntimeError(f"No {what} option matching {option_pattern.pattern!r}. Options: {labels}")


def set_options(page, model, aspect=None, quality=None):
    pick(page, SEL_MODEL, re.compile("^" + re.escape(model) + "$"), "model")
    pill = clean(page.get_by_test_id("ugi-generative-settings-button").inner_text())
    if model not in pill:
        raise RuntimeError(f"Model did not switch; settings show: {pill}")
    if aspect:
        # Options read like 方形 (1:1); 自動 has no ratio.
        pick(page, SEL_ASPECT, re.compile(r"\(" + re.escape(aspect) + r"\)$|^" + re.escape(aspect) + "$"), "aspect")
    if quality:
        pick(page, SEL_QUALITY, re.compile("^" + re.escape(quality) + "$"), "quality/resolution")
    page.keyboard.press("Escape")
    page.wait_for_timeout(500)


def read_cost(page):
    """Credit cost shown next to the 產生 button, or '' if it can't be found."""
    status = page.get_by_test_id("generation-cost-indicator-v2-button").get_by_role("status")
    page.wait_for_timeout(2000)  # the old model's cost lingers briefly after a switch
    for _ in range(20):
        if status.count():
            m = re.search(r"\d+", status.first.inner_text())
            if m:
                return m.group(0)
        page.wait_for_timeout(500)
    return ""


def thumb_labels(page):
    """Media strip, oldest first; each label is the prompt start plus a unique file id."""
    return page.locator(SEL_THUMB).evaluate_all("els => els.map(e => e.getAttribute('aria-label'))")


def add_refs(page, refs, out):
    """Feed reference images to the hidden file input behind 參考 and wait for the tray to show them."""
    tray = page.get_by_test_id("ugi-asset-tray")
    before = tray.locator("img").count()
    page.locator("input#file-input[type=file]").set_input_files([str(r) for r in refs])
    deadline = dt.datetime.now() + dt.timedelta(seconds=90)
    while tray.locator("img").count() < before + len(refs):
        if dt.datetime.now() > deadline:
            shot = Path(out).with_suffix(".error.png")
            page.screenshot(path=str(shot))
            raise RuntimeError(f"Reference upload not confirmed ({tray.locator('img').count() - before}/{len(refs)}); "
                               f"screenshot: {shot}")
        page.wait_for_timeout(1000)
    page.wait_for_timeout(2000)


def download_result(page, label, out):
    """Open the media-strip result with this label and save it through the 下載 button."""
    page.locator(SEL_THUMB).and_(page.locator(f'[aria-label="{label}"]')).first.click()
    page.wait_for_timeout(2500)
    # The result feed renders a 下載 button per nearby result; clicking the thumbnail
    # scrolls its result to the top, so take the visible button nearest the top.
    btns = page.get_by_test_id("toolbar-media-download")
    btns.first.wait_for(state="attached", timeout=60000)
    vh = page.viewport_size["height"]
    boxes = [(i, btns.nth(i).bounding_box()) for i in range(btns.count())]
    boxes = [(i, b) for i, b in boxes if b and -20 <= b["y"] < vh]
    if not boxes:
        raise RuntimeError("No visible 下載 button for the selected result")
    btn = btns.nth(min(boxes, key=lambda x: x[1]["y"])[0])
    with page.expect_download(timeout=120000) as dl:
        btn.click()
    d = dl.value
    out = Path(out)
    if not out.suffix:
        out = out.with_suffix(Path(d.suggested_filename).suffix or ".png")
    out.parent.mkdir(parents=True, exist_ok=True)
    d.save_as(str(out))
    return out


def generate(page, model, prompt, out, aspect=None, quality=None, refs=()):
    box = open_page(page)
    clear = page.get_by_test_id("ugi-clear-all-button")
    if clear.count() and clear.is_enabled():
        clear.click()  # drop a leftover prompt or references
        page.wait_for_timeout(1000)
    set_options(page, model, aspect, quality)
    if refs:
        add_refs(page, refs, out)
    box.click()
    box.fill(prompt)
    cost = read_cost(page)

    # Earlier results stay in the media strip; wait for a label we have not seen.
    before = set(thumb_labels(page))
    page.get_by_test_id("ugi-generate-button").click()
    deadline = dt.datetime.now() + dt.timedelta(milliseconds=GEN_TIMEOUT_MS)
    while True:
        new = [l for l in thumb_labels(page) if l not in before]
        if new:
            break
        if dt.datetime.now() > deadline:
            shot = Path(out).with_suffix(".error.png")
            page.screenshot(path=str(shot))
            raise RuntimeError(f"No result within {GEN_TIMEOUT_MS // 60000} min; screenshot: {shot}")
        page.wait_for_timeout(2000)
    page.wait_for_timeout(3000)
    out = download_result(page, new[-1], out)
    check_output(out, aspect)
    return out, cost.strip()


def cmd_fetch(args):
    """Download an existing result without generating: the newest, or the one whose label contains --label."""
    with sync_playwright() as p:
        ctx = open_context(p, args.headless)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        open_page(page)
        labels = thumb_labels(page)
        if args.label:
            labels = [l for l in labels if args.label in l]
        if not labels:
            sys.exit("No matching result in the media strip.")
        out = download_result(page, labels[-1], Path(args.out).resolve())
        print(f"saved {labels[-1]!r} -> {out}")
        ctx.close()


_seen_hashes = {}


def check_output(out, aspect):
    """Catch a download of the wrong result: duplicate of an earlier file, or wrong shape."""
    import hashlib
    from PIL import Image
    digest = hashlib.md5(out.read_bytes()).hexdigest()
    if digest in _seen_hashes:
        raise RuntimeError(f"Downloaded file is identical to {_seen_hashes[digest]} (stale result)")
    _seen_hashes[digest] = out.name
    if aspect:
        w, h = map(float, aspect.split(":"))
        with Image.open(out) as im:
            got = im.width / im.height
        if abs(got - w / h) / (w / h) > 0.05:
            raise RuntimeError(f"Image is {im.width}x{im.height}, not {aspect} (wrong result?)")


def cmd_options(args):
    """Print the aspect / quality / resolution choices Firefly offers for a model. Free."""
    model = resolve_model(args.model)
    with sync_playwright() as p:
        ctx = open_context(p, args.headless)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        open_page(page)
        set_options(page, model)
        print(f"model: {model}  cost at defaults: {read_cost(page)}")
        for what, sel in (("aspect", SEL_ASPECT), ("quality/resolution", SEL_QUALITY)):
            open_settings(page)
            picker = page.locator(sel)
            if not picker.count() or not picker.first.is_visible():
                print(f"{what}: (none)")
                continue
            picker.first.click()
            page.wait_for_timeout(800)
            print(f"{what}: {[clean(t) for t in page.get_by_role('option').all_inner_texts()]}")
            page.keyboard.press("Escape")
            page.wait_for_timeout(500)
        ctx.close()


def log_row(log_path, row):
    new = not log_path.exists()
    with open(log_path, "a", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        if new:
            w.writerow(["time", "id", "model", "cost", "status", "out", "prompt"])
        w.writerow(row)


def run_jobs(jobs, log_path, headless):
    failed = 0
    with sync_playwright() as p:
        for j in jobs:
            # Fresh browser per job: within one session Firefly keeps earlier results on
            # the page in an order we can't rely on, and the wrong image got downloaded.
            ctx = open_context(p, headless)
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            now = dt.datetime.now().isoformat(timespec="seconds")
            try:
                out, cost = generate(page, j["model"], j["prompt"], j["out"],
                                     j.get("aspect"), j.get("quality"), j.get("refs", ()))
                print(f"OK   {j['id']}  {j['model']}  cost={cost}  -> {out}")
                log_row(log_path, [now, j["id"], j["model"], cost, "ok", out, j["prompt"]])
            except Exception as e:
                failed += 1
                print(f"FAIL {j['id']}  {j['model']}  {e}")
                log_row(log_path, [now, j["id"], j["model"], "", f"fail: {e}", j["out"], j["prompt"]])
            ctx.close()
    return failed


def cmd_one(args):
    out = Path(args.out).resolve()
    job = {"id": out.stem, "model": resolve_model(args.model), "prompt": args.prompt, "out": out,
           "aspect": args.aspect, "quality": args.quality,
           "refs": [Path(r).resolve() for r in args.ref or []]}
    sys.exit(1 if run_jobs([job], out.parent / "firefly_log.tsv", args.headless) else 0)


def cmd_run(args):
    csv_path = Path(args.csv).resolve()
    base = csv_path.parent
    only = set(args.only.split(",")) if args.only else None
    jobs = []
    with open(csv_path, encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            if not (r.get("id") or "").strip() or (only and r["id"] not in only):
                continue
            refs = [base / x.strip() for x in (r.get("refs") or "").split(";") if x.strip()]
            for ref in refs:
                if not ref.exists():
                    sys.exit(f"{r['id']}: reference not found: {ref}")
            jobs.append({"id": r["id"], "model": resolve_model(r["model"].strip()),
                         "prompt": r["prompt"].strip(), "out": base / r["out"].strip(),
                         "aspect": (r.get("aspect") or "").strip() or None,
                         "quality": (r.get("quality") or "").strip() or None, "refs": refs})
    if not jobs:
        sys.exit("No jobs selected.")
    for j in jobs:
        print(f"{j['id']}: {j['model']} -> {j['out']}" + (f"  refs={len(j['refs'])}" if j["refs"] else ""))
    if args.dry_run:
        return
    sys.exit(1 if run_jobs(jobs, base / "firefly_log.tsv", args.headless) else 0)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("login").set_defaults(fn=cmd_login)
    s = sub.add_parser("options", help="list aspect/quality choices for a model")
    s.add_argument("--model", required=True)
    s.add_argument("--headless", action="store_true")
    s.set_defaults(fn=cmd_options)
    s = sub.add_parser("fetch", help="download the newest (or a named) existing result, no generation")
    s.add_argument("--out", required=True)
    s.add_argument("--label", help="part of the result's label, e.g. the start of its prompt")
    s.add_argument("--headless", action="store_true")
    s.set_defaults(fn=cmd_fetch)
    for name, fn in (("one", cmd_one), ("run", cmd_run)):
        s = sub.add_parser(name)
        s.set_defaults(fn=fn)
        s.add_argument("--headless", action="store_true", help="hide the browser (may be blocked by Adobe)")
        if name == "one":
            s.add_argument("--model", required=True)
            s.add_argument("--prompt", required=True)
            s.add_argument("--out", required=True)
            s.add_argument("--aspect")
            s.add_argument("--quality")
            s.add_argument("--ref", action="append")
        else:
            s.add_argument("csv")
            s.add_argument("--only", help="comma-separated job ids")
            s.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
