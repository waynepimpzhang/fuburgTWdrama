"""Generate images in Adobe Firefly's web UI and save them to chosen paths.

Drives firefly.adobe.com/generate/image with Playwright and the installed
Chrome, using a dedicated, persistent Chrome profile that stays logged in.

  python firefly_gen.py login
  python firefly_gen.py options --model nbpro
  python firefly_gen.py one --model gpt2 --prompt "..." --out a.png [--aspect 16:9] [--quality 高] [--ref x.jpg]
  python firefly_gen.py run jobs.csv [--only id1,id2] [--dry-run]

jobs.csv columns: id,model,prompt,out,aspect,quality,refs
  refs: reference image paths separated by ';'. Relative paths resolve
  against the CSV's folder. Each run appends to firefly_log.tsv next to it.
"""
import argparse
import csv
import datetime as dt
import os
import re
import sys
from pathlib import Path

from playwright.sync_api import TimeoutError as PWTimeout
from playwright.sync_api import sync_playwright

URL = "https://firefly.adobe.com/generate/image"
PROFILE = Path(os.environ.get("FIREFLY_PROFILE", Path.home() / ".firefly-gen" / "profile"))

# Aliases -> exact option labels in Firefly's model list (checked 2026-11-03).
MODELS = {
    "gpt2": "GPT Image 2",
    "flare": "GPT Image 2.5 Flare",
    "sunburst": "GPT Image 2.5 Sunburst",
    "nbpro": "Gemini 3 (Nano Banana Pro)",
    "nb2": "Gemini 3.1 (Nano Banana 2)",
    "ff5": "Firefly Image 5",
}

GEN_TIMEOUT_MS = 6 * 60 * 1000


def resolve_model(name):
    if name in MODELS:
        return MODELS[name]
    if name in MODELS.values():
        return name
    sys.exit(f"Unknown model '{name}'. Use one of: {', '.join(f'{k} ({v})' for k, v in MODELS.items())}")


def open_context(p, headless=False):
    PROFILE.mkdir(parents=True, exist_ok=True)
    return p.chromium.launch_persistent_context(
        str(PROFILE),
        channel="chrome",
        headless=headless,
        accept_downloads=True,
        viewport={"width": 1400, "height": 900},
    )


def cmd_login(_args):
    with sync_playwright() as p:
        ctx = open_context(p)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto(URL)
        print("Log in to Adobe in the opened window, then close the window.")
        page.wait_for_event("close", timeout=0)
        ctx.close()


def pick(page, combo_name, option_pattern):
    """Open the combobox whose label matches combo_name and click the matching option."""
    combo = page.get_by_role("combobox", name=re.compile(combo_name))
    combo.get_by_role("button").first.click()  # later buttons are leftover "Dismiss" overlays
    opt = page.get_by_role("option", name=option_pattern)
    try:
        opt.first.click(timeout=5000)
    except PWTimeout:
        labels = page.get_by_role("option").all_inner_texts()
        page.keyboard.press("Escape")
        raise RuntimeError(f"No option matching {option_pattern!r} in {combo_name}. Options: {labels}")


def read_cost(page):
    """Credit cost shown next to the 產生 button, or '' if it can't be found."""
    status = page.locator("[data-testid=generation-cost-indicator-v2-button] .credit-status-text")
    page.wait_for_timeout(2500)  # the old model's cost lingers briefly after a switch
    for _ in range(20):
        if status.count():
            m = re.search(r"\d+", status.first.inner_text())
            if m:
                return m.group(0)
        page.wait_for_timeout(500)
    return ""


def generate(page,model, prompt, out, aspect=None, quality=None, refs=()):
    page.goto(URL, timeout=90000, wait_until="domcontentloaded")
    prompt_box = page.get_by_role("textbox", name=re.compile("提示|Prompt"))
    prompt_box.wait_for(timeout=60000)
    if page.get_by_role("button", name=re.compile(r"^(登入|Sign in)$")).count():
        raise RuntimeError("Not logged in. Run: python firefly_gen.py login")

    pick(page, "模型|Model", re.compile("^" + re.escape(model) + "$"))
    page.get_by_role("combobox", name=re.compile("模型|Model")).get_by_role(
        "button", name=re.compile(re.escape(model))).wait_for(timeout=10000)
    if aspect:
        pick(page, "外觀比例|Aspect", re.compile(r"\(" + re.escape(aspect) + r"\)|^" + re.escape(aspect) + "$"))
    if quality:
        # GPT models call it 品質 (低/中/高); Nano Banana calls it 解析度 (512/1K/2K/4K).
        pick(page, "品質|解析度|Quality|Resolution", re.compile("^" + re.escape(quality) + "$"))
    if refs:
        # The 上傳檔案 button opens a source menu, not a file dialog; feed the hidden input
        # (accepts jpeg/png/webp only) and wait for the counter "參考影像 (n/6)".
        # Some models' input is non-multiple, so upload one file at a time and wait for
        # the counter to reach n before sending the next. Once a reference is loaded the
        # page has one input per filled slot (they REPLACE that slot) plus the empty
        # "add" slot last, so always feed the last input.
        for n, r in enumerate(refs, 1):
            page.locator("input[type=file]").last.set_input_files(str(r))
            counter = page.get_by_role("button", name=re.compile(rf"\({n}.\d+\)"))  # a literal '/' breaks Playwright's selector
            try:
                counter.first.wait_for(timeout=60000)
            except PWTimeout:
                shot = Path(out).with_suffix(".error.png")
                page.screenshot(path=str(shot), full_page=True)
                inputs = page.locator("input[type=file]")
                info = [(inputs.nth(i).get_attribute("id"), inputs.nth(i).get_attribute("multiple"))
                        for i in range(inputs.count())]
                raise RuntimeError(f"Reference upload not confirmed ({n}/{len(refs)}: {Path(r).name}); "
                                   f"file inputs={info}; screenshot: {shot}")

    prompt_box.fill(prompt)
    cost = read_cost(page)

    # Earlier results from the same browser session stay on the page, so wait for a
    # new 下載 button rather than any; the newest result is listed first.
    download_btns = page.get_by_role("button", name=re.compile(r"^(下載|Download)$"))
    before = download_btns.count()
    gen_btn = page.get_by_role("button", name=re.compile(r"^(產生|Generate)$"))
    gen_btn.click()
    deadline = dt.datetime.now() + dt.timedelta(milliseconds=GEN_TIMEOUT_MS)
    while download_btns.count() <= before:
        if dt.datetime.now() > deadline:
            shot = Path(out).with_suffix(".error.png")
            page.screenshot(path=str(shot))
            raise RuntimeError(f"No result within {GEN_TIMEOUT_MS // 60000} min; screenshot: {shot}")
        page.wait_for_timeout(2000)
    page.wait_for_timeout(1500)

    with page.expect_download(timeout=120000) as dl:
        download_btns.first.click()
    d = dl.value
    out = Path(out)
    if not out.suffix:
        out = out.with_suffix(Path(d.suggested_filename).suffix or ".png")
    out.parent.mkdir(parents=True, exist_ok=True)
    d.save_as(str(out))
    check_output(out, aspect)
    return out, cost.strip()


_seen_hashes = {}


def check_output(out, aspect):
    """Catch a download of the wrong result: duplicate of an earlier file, or wrong shape."""
    import hashlib
    from PIL import Image
    digest = hashlib.md5(out.read_bytes()).hexdigest()
    if digest in _seen_hashes:
        raise RuntimeError(f"Downloaded file is identical to {_seen_hashes[digest]} (stale result)")
    _seen_hashes[digest] = out.name
    if aspect:
        w, h = map(float, aspect.split(":"))
        with Image.open(out) as im:
            got = im.width / im.height
        if abs(got - w / h) / (w / h) > 0.05:
            raise RuntimeError(f"Image is {im.width}x{im.height}, not {aspect} (wrong result?)")


def cmd_options(args):
    """Print the aspect / quality / resolution choices Firefly offers for a model."""
    model = resolve_model(args.model)
    with sync_playwright() as p:
        ctx = open_context(p, args.headless)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto(URL)
        page.get_by_role("textbox", name=re.compile("提示|Prompt")).wait_for(timeout=60000)
        pick(page, "模型|Model", re.compile("^" + re.escape(model) + "$"))
        page.wait_for_timeout(1500)
        for combo in page.get_by_role("combobox").all():
            label = combo.get_attribute("aria-label") or combo.inner_text()
            combo.get_by_role("button").first.click()
            page.wait_for_timeout(800)
            print(f"{label}: {page.get_by_role('option').all_inner_texts()}")
            page.keyboard.press("Escape")
            page.wait_for_timeout(400)
        ctx.close()


def log_row(log_path, row):
    new = not log_path.exists()
    with open(log_path, "a", encoding="utf-8", newline="") as f:
        w = csv.writer(f, delimiter="\t")
        if new:
            w.writerow(["time", "id", "model", "cost", "status", "out", "prompt"])
        w.writerow(row)


def run_jobs(jobs, log_path, headless):
    failed = 0
    with sync_playwright() as p:
        for j in jobs:
            # Fresh browser per job: within one session Firefly keeps earlier results on
            # the page in an order we can't rely on, and the wrong image got downloaded.
            ctx = open_context(p, headless)
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            now = dt.datetime.now().isoformat(timespec="seconds")
            try:
                out, cost = generate(page, j["model"], j["prompt"], j["out"],
                                     j.get("aspect"), j.get("quality"), j.get("refs", ()))
                print(f"OK   {j['id']}  {j['model']}  cost={cost}  -> {out}")
                log_row(log_path, [now, j["id"], j["model"], cost, "ok", out, j["prompt"]])
            except Exception as e:
                failed += 1
                print(f"FAIL {j['id']}  {j['model']}  {e}")
                log_row(log_path, [now, j["id"], j["model"], "", f"fail: {e}", j["out"], j["prompt"]])
            ctx.close()
    return failed


def cmd_one(args):
    out = Path(args.out).resolve()
    job = {"id": out.stem, "model": resolve_model(args.model), "prompt": args.prompt, "out": out,
           "aspect": args.aspect, "quality": args.quality,
           "refs": [Path(r).resolve() for r in args.ref or []]}
    sys.exit(1 if run_jobs([job], out.parent / "firefly_log.tsv", args.headless) else 0)


def cmd_run(args):
    csv_path = Path(args.csv).resolve()
    base = csv_path.parent
    only = set(args.only.split(",")) if args.only else None
    jobs = []
    with open(csv_path, encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            if not (r.get("id") or "").strip() or (only and r["id"] not in only):
                continue
            refs = [base / x.strip() for x in (r.get("refs") or "").split(";") if x.strip()]
            for ref in refs:
                if not ref.exists():
                    sys.exit(f"{r['id']}: reference not found: {ref}")
            jobs.append({"id": r["id"], "model": resolve_model(r["model"].strip()),
                         "prompt": r["prompt"].strip(), "out": base / r["out"].strip(),
                         "aspect": (r.get("aspect") or "").strip() or None,
                         "quality": (r.get("quality") or "").strip() or None, "refs": refs})
    if not jobs:
        sys.exit("No jobs selected.")
    for j in jobs:
        print(f"{j['id']}: {j['model']} -> {j['out']}" + (f"  refs={len(j['refs'])}" if j["refs"] else ""))
    if args.dry_run:
        return
    sys.exit(1 if run_jobs(jobs, base / "firefly_log.tsv", args.headless) else 0)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("login").set_defaults(fn=cmd_login)
    s = sub.add_parser("options", help="list aspect/quality choices for a model")
    s.add_argument("--model", required=True)
    s.add_argument("--headless", action="store_true")
    s.set_defaults(fn=cmd_options)
    for name, fn in (("one", cmd_one), ("run", cmd_run)):
        s = sub.add_parser(name)
        s.set_defaults(fn=fn)
        s.add_argument("--headless", action="store_true", help="hide the browser (may be blocked by Adobe)")
        if name == "one":
            s.add_argument("--model", required=True)
            s.add_argument("--prompt", required=True)
            s.add_argument("--out", required=True)
            s.add_argument("--aspect")
            s.add_argument("--quality")
            s.add_argument("--ref", action="append")
        else:
            s.add_argument("csv")
            s.add_argument("--only", help="comma-separated job ids")
            s.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
