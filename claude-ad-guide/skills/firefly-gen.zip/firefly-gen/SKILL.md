---
name: firefly-gen
description: Generate images with the user's Adobe Firefly account (GPT Image 2, GPT Image 2.5 Flare / Sunburst, Nano Banana Pro, Nano Banana 2, Firefly Image 5) through a Playwright script, and save each result to a chosen path. Use when the user asks to generate or regenerate images "in Firefly", with GPT-image / Nano Banana through Firefly, or to batch-generate images from a prompt list into project folders. Do not drive Firefly by hand through a browser MCP; this script costs far fewer tokens.
---

# Firefly image generation

The script `scripts/firefly_gen.py` (next to this file) opens firefly.adobe.com in the installed Chrome with its own persistent profile (`~/.firefly-gen/profile`), picks the model, fills the prompt, clicks 產生, and saves the first result.

Every generation spends the user's Firefly credits. Measured 2026-11-03: GPT Image 2 中 = 20, GPT Image 2.5 Flare / Sunburst 中 = 5, Nano Banana 2 2K = 20, Nano Banana Pro 1K = 40. The log records the actual cost of each job. Show the user the job list and get a yes before running anything that generates. `--dry-run` and `options` are free.

## Models

| alias | Firefly label |
|---|---|
| `gpt2` | GPT Image 2 |
| `flare` | GPT Image 2.5 Flare |
| `sunburst` | GPT Image 2.5 Sunburst |
| `nbpro` | Gemini 3 (Nano Banana Pro) |
| `nb2` | Gemini 3.1 (Nano Banana 2) |
| `ff5` | Firefly Image 5 |

The full label also works. Choices per model (checked 2026-11-03; re-check with `options --model <alias>`):

| alias | aspect (`--aspect`) | quality (`--quality`) |
|---|---|---|
| `gpt2` | 21:9 16:9 5:4 4:3 3:2 1:1 4:5 3:4 2:3 9:16 | 低 中 高 |
| `flare`, `sunburst` | 3:2 1:1 2:3 only | 低 中 高 |
| `nbpro` | same as gpt2 | 1K 2K 4K (Firefly labels it 解析度) |
| `nb2` | gpt2's list plus 8:1 4:1 1:4 1:8 | 512 1K 2K 4K |

Empty aspect means 自動. Pass the ratio only (`9:16`), not the Chinese label.

## Commands

```
python <skill>/scripts/firefly_gen.py login                       # user logs in once, then closes the window
python <skill>/scripts/firefly_gen.py options --model nbpro       # aspect/quality choices, free
python <skill>/scripts/firefly_gen.py one --model gpt2 --prompt "..." --out path/name.png [--aspect 16:9] [--quality 高] [--ref img.jpg]
python <skill>/scripts/firefly_gen.py run jobs.csv [--only id1,id2] [--dry-run]
```

`jobs.csv` (UTF-8, header row): `id,model,prompt,out,aspect,quality,refs`. `out` and `refs` are relative to the CSV's folder; `refs` holds up to 6 reference images separated by `;`. Empty `aspect`/`quality` keep Firefly's defaults.

Reference images must be JPEG, PNG or WebP. Convert anything else first (`python -c "from PIL import Image; Image.open('x.avif').save('x.png')"`).

Each job gets a fresh browser launch: inside one session Firefly keeps earlier results on the page and the script once downloaded the previous job's image. After saving, the script fails a job whose file duplicates an earlier one in the run or whose shape doesn't match `aspect`.

Each run appends one row per job to `firefly_log.tsv` beside the CSV (or beside `--out`): time, id, model, credit cost, ok/fail, output path, prompt. Exit code is 1 if any job failed.

## After a run

- Read the log, then look at each output image and check every character of any text in it; models still miswrite Chinese. Report wrong characters instead of calling the job done.
- Firefly does not give transparent PNGs. Ask for a flat `#00FF00` background and key it out later.
- Only one script run at a time: the Chrome profile is locked while the window is open.

## When it fails

- `Not logged in` → ask the user to run `login` (or run it in the background and let them log in).
- `No option matching ...` → the error lists what Firefly offers; fix the value or the `MODELS` table.
- Timeout → a `.error.png` screenshot sits next to the intended output; look at it (content block, out of credits, UI change).
- After a Firefly redesign the role/label selectors in `generate()` may need updating. The UI labels are Traditional Chinese with English fallbacks.
