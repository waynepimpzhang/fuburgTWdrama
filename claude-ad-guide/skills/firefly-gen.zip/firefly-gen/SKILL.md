---
name: firefly-gen
description: Generate images with the user's Adobe Firefly account (GPT Image 2.6 Flare / Sunburst, GPT Image 2, Nano Banana Pro, Nano Banana 2, Nano Banana 2.1, Firefly Image 5) through a Playwright script, and save each result to a chosen path. Use when the user asks to generate or regenerate images "in Firefly", with GPT-image / Nano Banana through Firefly, or to batch-generate images from a prompt list into project folders. Do not drive Firefly by hand through a browser MCP; this script costs far fewer tokens.
---

# Firefly image generation

The script `scripts/firefly_gen.py` (next to this file) opens firefly.adobe.com/image-generate (the page Firefly moved to in 2026-11) in the installed Chrome with its own persistent profile (`~/.firefly-gen/profile`), picks the model, aspect and quality in the 生成式設定 popover, fills the prompt, clicks 產生, and downloads the new result from the media strip.

Every generation spends the user's Firefly credits. Shown 2026-11-13 at default settings: GPT Image 2.6 Flare / Sunburst 1K = 15, GPT Image 2.5 1K = 15, GPT Image 2 中 = 20, Nano Banana 2.1 1K = 10, Nano Banana 2 1K = 20, Nano Banana Pro 2K = 40, Firefly Image 5 1K = 10. Higher resolution costs more. The log records the actual cost of each job. Show the user the job list and get a yes before running anything that generates. `--dry-run`, `options` and `fetch` are free.

## Models

| alias | Firefly label |
|---|---|
| `flare` | GPT Image 2.6 Flare (default GPT choice) |
| `sunburst` | GPT Image 2.6 Sunburst |
| `gpt2` | GPT Image 2 |
| `flare25`, `sunburst25` | GPT Image 2.5 Flare / Sunburst (older, kept for re-runs) |
| `nbpro` | Gemini 3.0 (Nano Banana Pro) |
| `nb2` | Gemini 3.1 (Nano Banana 2) |
| `nb21` | Gemini Nano Banana 2.1 |
| `ff5` | Firefly Image 5 |

The full label also works. Choices per model (checked 2026-11-13; re-check with `options --model <alias>`):

| alias | aspect (`--aspect`) | quality (`--quality`) |
|---|---|---|
| `flare`, `sunburst`, `flare25`, `sunburst25` | 21:9 16:9 3:2 4:3 5:4 1:1 4:5 3:4 2:3 9:16 9:21 | 1K 2K 4K (解析度) |
| `gpt2` | 21:9 16:9 3:2 4:3 5:4 1:1 4:5 3:4 2:3 9:16 | 低 中 高 (品質) |
| `nbpro` | same as gpt2 | 1K 2K 4K |
| `nb2` | gpt2's list plus 8:1 4:1 1:4 1:8 | 512 1K 2K 4K |
| `nb21` | nb2's list without 自動 | 1K 2K 4K |
| `ff5` | 16:9 4:3 1:1 3:4 9:16 | 1K 2K |

Empty aspect means 自動 (nb21 has no 自動 and defaults to 1:1). Pass the ratio only (`9:16`), not the Chinese label.

## Commands

```
python <skill>/scripts/firefly_gen.py login                       # user logs in once, then closes the window
python <skill>/scripts/firefly_gen.py options --model nbpro       # aspect/quality choices, free
python <skill>/scripts/firefly_gen.py one --model flare --prompt "..." --out path/name.png [--aspect 16:9] [--quality 2K] [--ref img.jpg]
python <skill>/scripts/firefly_gen.py run jobs.csv [--only id1,id2] [--dry-run]
python <skill>/scripts/firefly_gen.py fetch --out path/name.png [--label "Close-up product"]   # re-download the newest result, or the newest whose label contains the text (labels hold the first ~30 characters of the prompt), free
```

`jobs.csv` (UTF-8, header row): `id,model,prompt,out,aspect,quality,refs`. `out` and `refs` are relative to the CSV's folder; `refs` holds reference images separated by `;`. Empty `aspect`/`quality` keep whatever the page used last (Firefly remembers settings between sessions), so set them when they matter.

Reference images must be JPEG, PNG or WebP. Convert anything else first (`python -c "from PIL import Image; Image.open('x.avif').save('x.png')"`).

Each job gets a fresh browser launch: inside one session Firefly keeps earlier results on the page and the script once downloaded the previous job's image. After saving, the script fails a job whose file duplicates an earlier one in the run or whose shape doesn't match `aspect`.

Each run appends one row per job to `firefly_log.tsv` beside the CSV (or beside `--out`): time, id, model, credit cost, ok/fail, output path, prompt. Exit code is 1 if any job failed.

## After a run

- Read the log, then look at each output image and check every character of any text in it; models still miswrite Chinese. Report wrong characters instead of calling the job done.
- Firefly does not give transparent PNGs. Ask for a flat `#00FF00` background and key it out later.
- Only one script run at a time: the Chrome profile is locked while the window is open.

## When it fails

- `Not logged in` → ask the user to run `login` (or run it in the background and let them log in).
- `No option matching ...` → the error lists what Firefly offers; fix the value or the `MODELS` table.
- Timeout → a `.error.png` screenshot sits next to the intended output; look at it (content block, out of credits, UI change).
- After a Firefly redesign the selectors may need updating. The script relies on `data-testid` values (`ugi-generative-settings-button`, `ugi-model-picker`, `ugi-aspect-ratio-picker`, `ugi-resolution-picker`, `ugi-prompt-input`, `ugi-generate-button`, `toolbar-media-download`, `ugi-clear-all-button`) because the visible labels carry zero-width spaces. The old page `firefly.adobe.com/generate/image` still loads but lacks the newer models.
