---
name: cred-ad-upload
description: Make and upload ads for Ad2iction's Cr.ED platform (cmp.ad2iction.com), checking each placement's limits before any asset is made. Use whenever the user names a Cr.ED / CrED module or AIC 提案 placement (Story, Motion, Immersion, 文中鎖屏, Action, 置底, 大插頁, 全屏, Plus, 序列圖 zip), asks to 上稿 to Cr.ED, or wants 5 s / 15 s video or key visuals turned into a Cr.ED ad.
---

# Cr.ED ad upload

Cr.ED is Ad2iction's template platform. You pick a module, upload assets into its form and get an ad tag. Nothing is coded. The work is to make assets that fit the placement's **limits** and fill the form correctly. A wrong size or weight is found only at upload time, after the assets are made, so limits come first.

## Work loop

1. **Pin the placement.** Run `python scripts/check_assets.py --list` and match the user's words to one id. If two could fit (Story 置底 or 置底＋全屏, 文中鎖屏 圖片版 or 圖影版), ask. Done when one id is chosen.
2. **Read the limits before making anything.** Run `python scripts/check_assets.py --spec <id>` and show the user the result as a short table: each component, its size, formats and weights, and the count. If it says UNVERIFIED, stop and ask for the spec (see `references/modules/motion.md`). Done when the user has seen the limits, and every planned asset (for example the 15 s MP4, each frame, the key visual) has a component it goes into.
3. **Read the module file** for the form fields and design rules: `references/modules/{story,immersion,lockscreen,action,motion}.md`.
4. **Make the assets** to those limits, into `<project>/cred/<id>/v<N>/<component>/`, one subfolder per component key from step 2. Keep important content in the red safe area. Extend backgrounds into the blue area, which may be cropped.
   - Finished footage that only needs a crop or re-encode: do it here with ffmpeg.
   - Anything composed (footage with key visuals, text or logo, animation, Immersion sequences) or a Motion **Adobe Animate** HTML zip (2MB on v1.3.1, 10MB on v1.2.9): use `html5-ad-unit`, which renders an MP4 or an HTML5 zip from one GSAP timeline and can build a local preview that never touches Cr.ED.
5. **Gate on the check.** Run `python scripts/check_assets.py <id> <folder>` (add `--copy copy.json` for Action). Fix every FAIL and re-run until it prints PASS. Report every WARN to the user. An Adobe Animate zip goes in an `animate/` subfolder; the same command checks it (one zip; add `--motion 1.2.9` for the older parent).
6. **Upload in Cr.ED.** The UI and its rules are in `references/ui.md`. Fill the form from the module file. Save, deploy, copy and delete only after the user confirms that exact action, because the ad list is shared production data. After saving, open 預覽 and check it on a phone-sized view.
7. **Wrap it in the parent.** A child ad does not play until a parent wraps it.
   - Publish the child to get its id.
   - Fill that id into a parent ad: Motion for Story, Action and Immersion 全屏/置底/Plus; Nation for every 文中 format (Immersion 文中 and 文中鎖屏).
   - Publish the parent, then check the parent's preview.
   - Each publish needs the user's confirmation.
   - Steps and fallbacks: `references/ui.md` § Parent and child modules.
8. **Name it** `<客戶名>-<活動名>_<版位簡稱>_<上稿者>_<秒數>`. Add the prefix `參考用_` for a test or demo. A demo's links are all `https://www.ad2iction.com`.

## Rules for every placement

- Limits come only from `references/placements.json` via the script. When the spec page and the upload form disagree, the JSON already holds the stricter value. Follow it.
- Images: JPG/PNG under 150KB and GIF under 400KB unless the placement says otherwise. 文中鎖屏 images are JPG only.
- Videos: MP4 (H.264), 100MB max. The site transcodes after upload; wait for the 影片連結 to work before previewing.
- Version folders count upward (`v1`, `v2` …). Never overwrite an earlier version.
- Login: read `CRED_ACCOUNT` / `CRED_PASSWORD` from `~/.cred/cred_ed.env` (keep the folder readable only by your own account). Never print the values or copy them into another file, a handoff or a memory. If the file is missing or empty, ask the user to fill it (ask the team for a Cr.ED account).

## When the site changes

Spec pages carry a 「最後更新時間」. When a check disagrees with what the site now accepts, re-read the spec page (`spec` URL in the JSON), update `placements.json`, and note the date in its `_source`.
