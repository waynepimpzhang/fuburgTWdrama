# Cr.ED upload UI

Read 2026-11-12 with an account that has (permissions: 建立廣告 / 廣告部署 / 瀏覽廣告規範). The login is read from `~/.cred/cred_ed.env` (see SKILL.md). It is never written into this skill.

## Pages

| Page | URL | What it is |
|---|---|---|
| 登入 | `https://cmp.ad2iction.com/#/login` | Account and password |
| 廣告列表 | `#/clientmodule/published` | Every ad from every user (about 222 pages). Search box, 批次刪除, 建立廣告. Columns: Privacy, Name, Ad Format, Ver., Size, Owner, Created Date, Actions |
| 建立廣告 | `#/clientmodule/build/published` | Step 1 of 3: pick a module card (Demo / 建立). Filters: Type (NEW, 展示型, 支援影片, 即時資訊, 互動型, 遊戲型, DCO) and Platform (Ad2, Web, DV360, GAM, Google Ads, TTD, Verizon, Xandr) |
| 編輯廣告 | `#/clientmodule/edit/published/update?cmid=…&mmid=…` | Step 2: 上傳/更新素材. Buttons 預覽 and 儲存 at the top right |
| 部署廣告 | `#/clientmodule/deploy/<cmid>` | Step 3: Name, Ad Format, File size, Platform, Ad tag |
| 廣告規範 | `#/spec-home`, `#/spec-module/all`, `#/spec/<mmid>` | Spec pages. The `?` button in the header leads here |

Row actions in 廣告列表: Preview, Edit, Deploy, Copy and Delete.
- the uploader's account can delete its own ads with the **Delete** button at the far right of the row. The button sits off-screen in a narrow window, so scroll the table right to reach it.
- An earlier note said Delete was disabled. The user corrected that on 2026-11-13.
- Deleting is still shared production data. Delete only the ads the user names, after they confirm.

Preview is a menu with three choices: Ad2, Ad2news and Device.
- **Device** opens `demo2.now-tracking.com/demo/device.php?id=<cmid>&…`.
- When the user asks for an ad's 「device 網址」, this is the link they mean.
- Get the parent ad's link, because a child ad does not play on its own.
- Script: `<team tools>\cred_listprev1.py "<name>|<name>…" <shot>`.

`cmid` is the ad. `mmid` is the module type (Story is `<mmid>`, Immersion 全屏/置底/Plus is `<mmid>`, Immersion 文中 is `<mmid>`, 文中鎖屏 is `<mmid>` in the editor and `<mmid>` on the spec page, Action is `<mmid>`).

## Parent and child modules

The team's placements are a **child module** (Story, Immersion, 文中鎖屏, Action) wrapped in a **parent module**: `Motion-魔動星軌` for Story, Action and Immersion 全屏/置底/Plus, and `Nation` for every 文中 format (Immersion 文中 and 文中鎖屏). The user confirmed on 2026-11-13 that Immersion 文中 goes in Nation. A Motion wrap was tried first and deleted. **A child ad never plays on its own**: its preview shows an empty slot until a parent wraps it (the user confirmed this 2026-11-12).

Steps to make a child ad playable:

1. Save the child ad.
2. Publish (deploy) the child ad. Publishing gives it an id.
3. Open a parent ad of the matching module, fill in the child ad's id, then save and publish the parent.
   - The child id is the Ad tag on the child's 部署廣告 page, `#/clientmodule/deploy/<cmid>`.
   - Opening that page is all "publish" takes; there is no publish button.
   - Read the tags with `<team tools>\cred_tags.py <cmid…>`.
   - The parent cards appear on the 建立廣告 page only once the account has parent permission. Ask Ad2 staff to grant it.
4. Preview the **parent** ad. That preview is the one to check on a phone.

Parent fields that worked on 2026-11-12. These played in a 390px headless preview:
- **Motion** card (v1.3.1, mmid `<mmid>`), for Story, Action and Immersion 全屏/置底/Plus (not 文中):
  - 上傳格式 `Exp2.0`
  - Module ID = the child's ad tag
  - 階層 1
  - width and height = the ad size
  - Every other field left at its default
- **Nation** card (v1.3.2, mmid `<mmid>`), for Immersion 文中 and 文中鎖屏:
  - 上傳格式 `EXP 2.0 (滿版限定)`
  - Module ID = the child's ad tag
  - 階層 1, with 版面高度 left at its default of 2
- Script: `<team tools>\cred_parent.py <create_url> <title> <ad tag> <outdir> --fmt <format> --set "label=value" [--save]`.
- Parent title: the child's name plus `_fbp`, as the team's ads do.
- On the build page, the card title is `div.list-item-content-header`. A hidden filter `<li>` has the same text, so a plain text match clicks the wrong card. `cred_create_probe.py` handles this.

Publishing is outward-facing. Ask before each one, even for demos.

### Motion 上傳格式 (read 2026-11-12 on a Motion v1.3.1 ad, nothing saved)

Options: 無 / **Adobe Animate** / 捲軸動畫模組 Motion / **Exp2.0** (wraps a child by Module ID) / Campaign.

**Adobe Animate** replaces the Module ID field with an **Animate Zip** upload (`.zip`: 2MB on Motion v1.3.1, 10MB on Motion-魔動星軌 v1.2.9). The zip needs exactly one `.html` at its root; name it `index.html`. The fields below it are the same for every format:
- 階層 (0 = disabled), 啟動Debug邊框線, 垂直對齊 (上 / 中 / 下)
- 關閉按鈕位置 (左側 / 右側), 關閉按鈕起始位置 (置底 / 置頂), 關閉按鈕距起始位置 (%)
- **width / height**: the placement size in px (the team's 文中 ads use 640 x 1280). Build the Animate canvas at this size.
- 啟動自動撥放, 卷軸距離 (px, 300–800 recommended)
- 寬螢幕填充功能: 無 / image / code
- 新增互動按鈕, 新增EXPLOSION. Interaction buttons carry the clicks: 互動按鈕對應名字 `…_click_through` (so the report counts clicks) plus the url below it. Their fields and how an Adobe Animate creative shows them (`motionSet`) are in `html5-ad-unit/references/html5-output.md`.

Gotcha: after switching 上傳格式 and leaving without saving, the editor can show the unsaved choice when the ad is reopened in the same tab. Reload the page to see the saved value.

On 2026-11-12 the uploader's account opened parent-module forms and got 「無法取得表單資料」. If that still happens, hand the child ad's name and id to Ad2 staff  to wrap.

## Sections every child form shares

1. **基本資料**: 標題 (required), 描述.
2. **內容設定**: module-specific, see the module file.
3. **Preview Setting**: Position = In-Content ad / Sticky bottom ad / Cover ad. Sticky bottom and Cover only work on Google Ad Manager. AD CI Display = Do not display / AD2 LOGO.
4. **第三方追蹤碼設定**: 是否開啟第三方追蹤 (required, 否/是). Cr.ED does not guarantee third-party trackers. Two trackers on the same event overwrite each other.

Upload fields say 「Drag file here, or click to upload」. A video needs time to transcode after upload. Click the 「影片連結」 link under the field to confirm it is ready before previewing.

Leaving an edit page with unsaved changes shows 「你的修改將不會被保留，確定要離開嗎？」.

## Naming (the user's rule, 2026-11-12)

`<客戶名>-<活動名>_<版位簡稱>_<上稿者>_<秒數>`, for example `客戶A-活動B_Immersion文中_<上稿者>_5s`.

- A test or demo ad gets the prefix `參考用_`.
- A demo ad's outbound links are all `https://www.ad2iction.com`.
- Older ads in the list use a longer form, `<單號> <業務名>_已上稿_…`. Do not copy it for new ads.

## Reference ads (參考用, read-only examples)

The team sheet links one finished example per placement. Ask the team for it, open them to see a correct setup, and never save them.

## Learned 2026-11-12 (Immersion 文中 test upload)

- Clicking 建立 → dialog 新增 **creates an untitled ad record in the shared list right away** (Name empty, Owner = you), before any 儲存. Reuse the `create?cmid=…` URL instead of pressing 新增 again; tell the user about each record it makes.
- 預覽 works without 儲存: it builds `https://mod2.ad2iction.com/mods/212/preview_<cmid>/index.html` server-side and opens `demo2.now-tracking.com/demo/prev.php?...id=preview_<cmid>`.
- In headless Playwright (desktop or iPhone emulation) the 文中 and 全屏 previews show the article but the ad iframe stays 0×0, even for the 參考用 ads. Have the user check the preview URL on a real phone.
- Form mechanics: 素材 tab add button `.cred-tab2-add-button`; 素材類型 is a `.cred-select` (pick 序列圖); the zip goes into the file input of the `* 序列圖` field group; upload is done when ~frame-count thumbnails (`img`) appear under it — the drop zone stays. 播完序列圖的時間區段 inputs are read-only (slider), default 0–100. 素材動畫設定 defaults to 固定位置. Scripts: `<team tools>\cred_login.py` / `cred_fill.py`.

## Driving the site with a browser tool

- Open it in an isolated browser context, so the session stays apart from the user's own browser.
- Read a form with `document.querySelector('main').innerText`. Labels and hints come through, field values do not.
- To leave a form you have not changed, navigate away and confirm the leave dialog.
- Saving, deploying, copying and deleting change shared production data. Do each one only after the user confirms that exact action.
