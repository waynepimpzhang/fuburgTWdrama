# 文中鎖屏 (`lockscreen-image`, `lockscreen-mixed`, `lockscreen-vvideo`)

Limits: `scripts/check_assets.py --spec <id>`. This file covers the upload form.

An in-article placement that takes over the screen while the reader passes it. Images slide like pages. The parent module is Nation.

| Placement | What it holds |
|---|---|
| lockscreen-image (圖片版) | 1–5 images, 640x1280 |
| lockscreen-mixed (圖影版) | One 16:9 video (top or bottom) plus 1–5 images, 640x920 |
| lockscreen-vvideo (直式影片版) | One 640x1280 vertical video plus a 640x1280 background shown before the video starts |

**Images are JPG only, under 150KB** per the spec. The upload form also accepts PNG, WebP and GIF; follow the spec.

## Form: 內容設定

- **啟用影片** → 影片設定: 使用 VAST 4.0 XML? 否/是. 影片檔 (.mp4, 100MB). 影片位置: 置頂 / 置底. 音量按鈕位置. 顯示播放按鈕 and 顯示影片預覽圖: these only appear when the video cannot autoplay.
- **圖片數量**: 單圖 / 多圖 → 圖片 uploads (the form hint says 640x920 when video is on).
- **預設連結**: for images that have no link of their own (1–5 links for images, 1 for the video).
- **顯示向上滑動操作提示**: 否 / 是.
- **啟用置底圖片**: pinned to the window bottom.
- **啟用導引光圈功能**: on or off, with line and glow colours.
- **啟用互動增益** → 0.1–1.
- **啟用滑動粒子特效**.
- Five page transitions to choose from: preview at (link in the Cr.ED form hint)

## Design notes from the spec

- Important content inside the red frame. Blue may be cropped, so extend the background into it.
- For alcohol brands the 酒類警語 overlay has its own safe-area chart: (link in the Cr.ED form hint)
- A 15 s vertical video from the video workflow fits `lockscreen-vvideo` once scaled to 640x1280 (9:18). A 9:16 master needs letterboxing or a crop. Decide which with the user before rendering.
