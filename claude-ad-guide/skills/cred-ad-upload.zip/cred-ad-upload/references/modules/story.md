# Story (`story-full`, `story-bottom`, `story-bottom-full`)

Limits: `scripts/check_assets.py --spec <id>`. This file covers the upload form and how the three placements map onto it.

Story extends the Instagram story idea into network ads: several pages, emoji reactions, images or short video. It is one module. The three placements come from the 顯示設定 checkboxes:

| Placement | 顯示設定 |
|---|---|
| story-full | 大插頁 only |
| story-bottom | 置底頁 only |
| story-bottom-full | 置底頁 + 大插頁 |

## Form: 內容設定

- **顯示設定** (required): 置底頁 / 大插頁 checkboxes.
- **置底頁點擊互動**: 開啟外連 or 開啟大插頁. 「開啟大插頁」 needs both checkboxes on.
- **顯示上滑提示動畫**: 否 / 是.
- **預設外連連結** (required): used by every page that has no link of its own.

### 置底頁設定 (bottom pages)
- 啟用品牌頭貼 → 品牌頭貼 upload (single or carousel; carousel: 0.5 s transition, 2.5 s hold). 頭貼邊框: 預設 / 自選顏色 / 自行上傳.
- 播放方式: 自動 / 捲動. 顯示播放進度條: 否/是 (only in 捲動+自動 or 自動). 捲動間隔秒數.
- 新增置底頁: up to 5 (置底頁 1–5). For each page:
  - 素材類型: 圖片 / 影片. 停留時間 (seconds).
  - 圖片 (640x320).
  - 互動表情符號: 關閉 or one of 拍手 / 火 / 讚 / 驚訝 / 笑哭 / 愛心.
  - 對應展開大插頁: which 大插頁 this page opens.
  - 外連連結.
  - Video position: 預設 (16:9) or 自訂 左 / 中 / 右 (1:1 recommended). With video on, turning the brand avatar off is recommended.

### 大插頁設定 (full-screen pages)
- Up to 5 pages. For each page:
  - 素材類型: 圖片 / 影片.
  - 影片設定: 使用 VAST 4.0 XML? 否/是. 影片檔 (.mp4). 置頂距離 in vw (0 = video at the top; the progress bar is 5vw tall).
  - 背景圖片 (640x1386, required; it sits behind the video).
  - 音量按鈕位置. 互動表情符號. 外連連結. 自訂按壓觸發外連延遲時間 (default 250 ms).
- 啟用滑動粒子特效: 彈跳 / 爆炸 / 雪花 / 氣泡, strength 低/中/高, count 1–30, style 預設 / 輸入文字 (1–3 characters or an emoji is best) / 自行上傳 (70x70).

## Design notes from the spec

- Red area = safe area. Blue area = may be cropped depending on the phone. Extend the background into the blue area.
- With the progress bar on, keep content out of the bar's area on bottom pages.
- 1x1 (OOP) format.
- The 5 s / 15 s MP4s from the video workflow go in as 大插頁 videos (any ratio, width-filled) or 置底 videos (16:9 default slot, 1:1 custom slot). Make the 640x1386 背景圖 to match the video.
