# Immersion (`immersion-full`, `immersion-bottom`, `immersion-plus`, `immersion-inline`)

Limits: `scripts/check_assets.py --spec <id>`. This file covers the upload form and the sequence workflow.

Immersion plays layered assets as the reader scrolls (parallax). Two child modules exist:
- `Immersion(全屏/置底/Plus)` for 640x1386, 640x320 and 640x500. The parent module is Motion.
- `Immersion(文中)` for 640x1280 in-article. The parent module is **Nation**, not Motion. The user confirmed this on 2026-11-13, after a Motion wrap was tried and deleted. The team's reference ad 悠遊卡 Immersion(文中版)_fbp is also a Nation ad.

## Video becomes a sequence

The team sheet says 「影片要轉序列圖」. Each 素材 is uploaded as a **序列圖 .zip** (20MB max per zip) of numbered frames at the placement size. The platform serves them as `00.webp, 01.webp…`. The reference 全屏 ad uses 96 frames at 640x1388, about 16KB each.

Frame extraction and compression are in the `html5-ad-unit` skill, `references/asset-pipeline.md` (steps 1–4). Size the frames to the placement width (640).

Still unconfirmed: the frame file type and naming the zip must contain. Copy the reference ad's pattern (two-digit numbers from `00`) and confirm with Ad2 staff before the first real upload.

## Form: 內容設定

- **互動完成距離**: how many screen heights of scrolling until the piece finishes (2 = done after two screens). **For `immersion-inline` it must be 1.** The Nation parent's 版面高度 sets the real distance.
- **進度條**: 關閉 / 啟動, with a colour.
- **終點停格**: when on, the last frame stays when the bar reaches 100%.
- **預設外連連結**.
- 文中 only: 顯示向上滑動操作提示. 啟用置底圖片 (pinned to the window bottom, always on top).
- **啟用互動增益** → 互動增益 0.1–1 (two decimals; lower triggers more easily).
- **啟用滑動粒子特效** (same options as Story).

### 素材 1…n (one block per layer)
- 素材類型: 序列圖 (zip).
- 外連功能: 否 / 是 → 序列圖外連連結 (falls back to the default link).
- Initial transform: 縮放大小 (width multiple 0–10; 1 = the ad's width), X / Y position in % from the top-left corner, Z order (default 2, min 1, a higher Z draws on top, ties go to the higher 素材 number), 透明度 0–1, 旋轉角度 −360–360.
- 播放方式: 單次 / 無限循環.
- 播完序列圖的時間區段: the scroll range in % over which the sequence plays fully (for example 0–50%).
- 素材動畫設定: 固定位置 / 視差捲動.
- 進場時間 / 退場時間 in % of scroll (0 = no exit). 進場的動畫 / 退場的動畫: duration %, delay %, easing (Linear …), target scale / X / Y / opacity / rotation.

The spec also says each asset's entry and exit effects go into a 腳本表 (script sheet). Ask the user for the sheet template.

## Video component

The spec also lists one optional MP4 (any ratio, 100MB, 30 s or less recommended, position and scale adjustable). Phones in power-saving mode do not autoplay it, so supply a preview image at the same size.

## Safe area

Blue = safe area (文中). Purple = progress-bar area.
