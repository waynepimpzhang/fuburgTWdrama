# Motion-魔動星軌 (`motion-full`, `motion-bottom`, `motion-lite`)

**Unverified.** Motion is the parent module. The team sheet lists three Motion-only placements, used without a child module:

| Placement | Size | Demo |
|---|---|---|
| motion-full (全屏) | 640x1386 | <demo link from the team sheet> |
| motion-bottom (置底版 無插頁) | 640x320 | <demo link from the team sheet> |
| motion-lite (Lite) | 前置動畫 640x1386 + 640x320 | <demo link from the team sheet> |

Motion has no public spec page, and the uploader's account cannot open its form (「無法取得表單資料」). Formats, weight limits, counts and what the 前置動畫 accepts are unknown.

Before making assets for these: ask the user to get the spec from Ad2 staff, then fill it into `placements.json` (`components`, `formats`, `qty`) and set `"verified": true`. Until then `check_assets.py` fails every Motion-only check on purpose.

Motion is also the parent of Story, Immersion (全屏/置底/Plus) and Action. To wrap a child ad, publish it to get its id, then fill that id into a Motion parent ad (see `../ui.md` § Parent and child modules).

## Adobe Animate format

Motion's 格式 has an **Adobe Animate** option: an HTML5 canvas creative packed as one zip, 2MB max (user, 2026-11-12). Build it with `html5-ad-unit` (`references/html5-output.md`). Still unconfirmed: entry file name, canvas size, CDN use, click handling (see `animate_cc.unverified` in `placements.json`).
