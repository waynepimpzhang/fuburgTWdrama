# Action (`action-image`, `action-video`)

Limits and copy lengths: `scripts/check_assets.py --spec <id>`. This file covers the upload form.

A 640x320 bottom banner with a marquee of AI-written copy. The copy is generated from keywords found on the article page. The parent module is Motion.

## Form: 內容設定

### 文案
- 文案類型: **AI 文案** / 自訂文案 / 墊檔文案 (fallback). 文案 1, 文案 2 … with 刪除全部.
- AI inputs: 產品類型 (10 characters max, e.g. 球鞋), 產品描述 (100 max), 產品關鍵字 (1–6 items, 12 characters each, one appears in each AI line), 風格 (default 正式), 表情符號 on or off.
- Your own copy: 80 characters max per line.
- 文章墊檔關鍵字: exactly 5 items, 4 Chinese characters each. Used when the page has no matching keywords.
- 開啟 AI 智能推薦提示: 否 / 是.

### 樣式與動畫
- 選擇款式: 黑色款 / 白色款 / 藍色款, or 自訂跑馬燈底圖 (600x76 PNG; template: (link in the Cr.ED form hint)). The marquee text colour follows the style.
- 啟動分析中動畫, 啟動關鍵字動畫.
- 跑馬燈每秒移動像素: 10–300 (higher is faster). 跑馬燈輪播間隔: 0–1 (smaller waits longer; 0 waits for the full run). 跑馬燈播兩次: 否 / 是.
- Carousel: auto or swipe. The image transition is picked at random: (link in the Cr.ED form hint)

### 外連設定
- 預設連結 (images without a link use it). Image version: 2–5 links. Video version: 1.
- 啟動上滑外連 → 上滑距離 (% of the placement height). 顯示上滑提示動畫.
- 啟動文章類型指定外連 (a different link per article type).

### 上傳格式: 圖片 / 影片
- 圖片: 2–5 bottom images, 640x320.
- 影片: VAST 4.0 option, .mp4 (16:9 or 1:1, 100MB). 影片背景: 黑色 / 透明 / 上傳圖片 (640x320, below the video). 影片外觀: 預設 / 自訂. 影片填滿方式: 撐滿寬 / 撐滿高. 音量開關按鈕位置. 圖檔 (640x320, above the video, used as a frame).

## Design notes

Important content inside the red frame. Write the copy fields into a `copy.json` (keys `product_type`, `product_desc`, `keywords`, `custom_copy`, `fallback_keywords`) and run the check with `--copy copy.json`.
