"""Check Cr.ED placement limits.

  python check_assets.py --list                 list placement ids
  python check_assets.py --spec <id>            print the limits (run this before making any asset)
  python check_assets.py <id> <asset_dir>       check a finished asset folder
  python check_assets.py <id> <asset_dir> --copy copy.json   also check Action copy

<asset_dir> holds one subfolder per component key from --spec (e.g. bottom/, interstitial/, video/).
Exit code 1 when anything fails, so it can gate packaging.
"""
import json
import subprocess
import sys
import zipfile
from fractions import Fraction
from pathlib import Path

from PIL import Image

HERE = Path(__file__).resolve().parent
DATA = json.loads((HERE.parent / "references" / "placements.json").read_text(encoding="utf-8"))
PLACEMENTS = DATA["placements"]
IMG_EXT = {"jpg", "jpeg", "png", "gif", "webp"}


def ext_of(p):
    e = p.suffix.lower().lstrip(".")
    return "jpg" if e == "jpeg" else e


def fmt_kb(kb):
    return f"{kb // 1024}MB" if kb >= 1024 else f"{kb}KB"


def print_spec(pid):
    p = PLACEMENTS[pid]
    print(f"{pid}  {p['name']}  ({p['ad_size']})")
    print(f"  module: {p['module']}" + (f"  parent: {p['parent']}" if p.get("parent") else ""))
    for k in ("spec", "demo"):
        if p.get(k):
            print(f"  {k}: {p[k]}")
    if not p.get("verified"):
        print("  !! UNVERIFIED: only the size comes from the team sheet. No spec page or upload form was readable.")
        print("     Ask the user (or Ad2 staff) for formats, weights and counts before making assets.")
    for key, c in p["components"].items():
        size = "x".join(map(str, c["size"])) if c.get("size") else f"ratio {c.get('ratio', 'any')}"
        fm = ", ".join(f"{e.upper()}<{fmt_kb(v)}" for e, v in c["formats"].items()) or "formats unknown"
        q = c["qty"]
        print(f"  [{key}] {c['label']}: {size}; {fm}; qty {q[0]}-{q[1]}" + (" (optional)" if q[0] == 0 else ""))
        if c.get("frame_formats"):
            print("      frames: " + ", ".join(f"{e.upper()}<{fmt_kb(v)}" for e, v in c["frame_formats"].items()))
        if c.get("max_seconds"):
            print(f"      length: {c['max_seconds']}s max (recommended)")
        if c.get("note"):
            print(f"      note: {c['note']}")
        if c.get("form_allows"):
            print("      upload form also accepts: " + ", ".join(f"{e.upper()}<{fmt_kb(v)}" for e, v in c["form_allows"].items()) + " (spec is stricter; follow the spec)")
    a = DATA.get("animate_cc")
    if a:
        lim = "、".join(f"v{v} <{fmt_kb(k)}" for v, k in a["max_kb_by_parent"].items())
        print(f"  output: 影片／圖片（上面的元件），或 Motion 格式選「Adobe Animate」：HTML canvas 打包成 1 個 zip（{lim}；用 --motion 1.2.9 檢查舊版）。")
        print("      put that zip in <folder>/animate/ and run the check")
        if a.get("unverified"):
            print("      Adobe Animate 未確認：" + "、".join(a["unverified"]))
        if a.get("clicks"):
            print("      點擊：" + a["clicks"])
    if p.get("copy"):
        print("  copy fields:")
        for k, r in DATA["copy_rules"][p["copy"]].items():
            cnt = f", {r['count'][0]}-{r['count'][1]} items" if r.get("count") else ""
            print(f"    {k} ({r['label']}): <= {r['max_chars']} chars{cnt}")


def ratio_ok(w, h, want):
    if want in (None, "any"):
        return True
    r = Fraction(w, h)
    for opt in want.split("|"):
        a, b = map(int, opt.split(":"))
        if abs(float(r) - a / b) < 0.01:
            return True
    return False


def probe(p):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
         "stream=width,height,codec_name:format=duration", "-of", "json", str(p)],
        capture_output=True, text=True)
    j = json.loads(out.stdout or "{}")
    s = (j.get("streams") or [{}])[0]
    return s.get("width"), s.get("height"), s.get("codec_name"), float(j.get("format", {}).get("duration", 0) or 0)


def check_image(path, c, limits, errs, warns, label):
    e = ext_of(path)
    kb = path.stat().st_size / 1024
    if e not in limits:
        errs.append(f"{label}: .{e} not allowed (allowed: {', '.join(limits)})")
        return
    if kb > limits[e]:
        errs.append(f"{label}: {kb:.0f}KB > {fmt_kb(limits[e])}")
    with Image.open(path) as im:
        w, h = im.size
    if c.get("size"):
        W, H = c["size"]
        if (w, h) != (W, H):
            if Fraction(w, h) == Fraction(W, H):
                warns.append(f"{label}: {w}x{h} has the right ratio but the spec size is {W}x{H}")
            else:
                errs.append(f"{label}: {w}x{h}, needs {W}x{H}")


def check_component(key, c, folder, errs, warns):
    files = sorted(f for f in folder.iterdir() if f.is_file()) if folder.is_dir() else []
    lo, hi = c["qty"]
    if not (lo <= len(files) <= hi):
        (errs if lo > 0 or len(files) > hi else warns).append(f"[{key}] {len(files)} file(s), allowed {lo}-{hi}")
    for f in files:
        label = f"[{key}] {f.name}"
        e = ext_of(f)
        if e == "zip":
            kb = f.stat().st_size / 1024
            if "zip" not in c["formats"]:
                errs.append(f"{label}: zip not allowed here")
                continue
            if kb > c["formats"]["zip"]:
                errs.append(f"{label}: {kb / 1024:.1f}MB > {fmt_kb(c['formats']['zip'])}")
            with zipfile.ZipFile(f) as z:
                frames = [n for n in z.namelist() if not n.endswith("/") and Path(n).suffix.lower().lstrip(".") in IMG_EXT]
                sizes = set()
                for n in frames:
                    with z.open(n) as fh:
                        with Image.open(fh) as im:
                            sizes.add(im.size)
                    fk = z.getinfo(n).file_size / 1024
                    lim = c.get("frame_formats", {}).get(ext_of(Path(n)))
                    if lim and fk > lim:
                        errs.append(f"{label}/{n}: {fk:.0f}KB > {fmt_kb(lim)}")
            warns.append(f"{label}: {len(frames)} frames, sizes {sorted(sizes)}")
            if c.get("size") and any(abs(w / h - c['size'][0] / c['size'][1]) > 0.01 for w, h in sizes):
                errs.append(f"{label}: frame ratio differs from {c['size'][0]}x{c['size'][1]}")
        elif e == "mp4" or e in ("mov", "webm"):
            if e not in c["formats"]:
                errs.append(f"{label}: .{e} not allowed (needs mp4)")
                continue
            mb = f.stat().st_size / 1024 / 1024
            if mb * 1024 > c["formats"]["mp4"]:
                errs.append(f"{label}: {mb:.1f}MB > {fmt_kb(c['formats']['mp4'])}")
            w, h, codec, dur = probe(f)
            if w and not ratio_ok(w, h, c.get("ratio")):
                errs.append(f"{label}: {w}x{h} is not {c['ratio']}")
            if w and c.get("size") and not c.get("ratio") and (w, h) != tuple(c["size"]) and Fraction(w, h) != Fraction(*c["size"]):
                errs.append(f"{label}: {w}x{h}, needs {c['size'][0]}x{c['size'][1]}")
            if codec and codec != "h264":
                warns.append(f"{label}: codec {codec}; H.264 is the safe choice")
            if c.get("max_seconds") and dur > c["max_seconds"]:
                warns.append(f"{label}: {dur:.1f}s, recommended <= {c['max_seconds']}s")
        elif e in IMG_EXT:
            check_image(f, c, c["formats"], errs, warns, label)
        else:
            errs.append(f"{label}: unexpected file type")


def check_animate(folder, errs, warns, motion="1.3.1"):
    """Adobe Animate upload: one HTML5 canvas zip under the Motion limit."""
    a = DATA["animate_cc"]
    zips = sorted(folder.glob("*.zip"))
    if len(zips) != 1:
        errs.append(f"[animate] {len(zips)} zip(s), needs exactly 1")
    for z in zips:
        kb = z.stat().st_size / 1024
        lim = a["max_kb_by_parent"][motion]
        if kb > lim:
            errs.append(f"[animate] {z.name}: {kb:.0f}KB > {fmt_kb(lim)} (Motion v{motion})")
        with zipfile.ZipFile(z) as zf:
            names = zf.namelist()
            root_html = [n for n in names if "/" not in n and n.lower().endswith(".html")]
            if len(root_html) != 1:
                errs.append(f"[animate] {z.name}: {len(root_html)} .html file(s) at the zip root, needs exactly 1")
            elif root_html[0] != "index.html":
                warns.append(f"[animate] {z.name}: entry is {root_html[0]}; it plays (the platform finds the one root .html), index.html is preferred")
            for n in names:
                if n.lower().endswith((".html", ".js", ".css")):
                    text = zf.read(n).decode("utf-8", "ignore")
                    if "http://" in text or "https://" in text:
                        warns.append(f"[animate] {z.name}/{n}: has an external URL; pack libraries locally, and put landing URLs in the Motion interaction buttons, not in the creative")
        warns.append(f"[animate] {z.name}: {kb:.0f}KB, {len(names)} files")


def check_copy(rules, path, errs):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    for k, r in rules.items():
        if k not in data:
            continue
        v = data[k]
        items = v if isinstance(v, list) else [v]
        if r.get("count") and not (r["count"][0] <= len(items) <= r["count"][1]):
            errs.append(f"copy.{k}: {len(items)} items, needs {r['count'][0]}-{r['count'][1]}")
        for s in items:
            if len(s) > r["max_chars"]:
                errs.append(f"copy.{k}: '{s}' is {len(s)} chars > {r['max_chars']}")


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    if argv[0] == "--list":
        for pid, p in PLACEMENTS.items():
            flag = "" if p.get("verified") else "  (unverified)"
            print(f"{pid:20} {p['ad_size']:28} {p['name']}{flag}")
        return 0
    if argv[0] == "--spec":
        print_spec(argv[1])
        return 0
    pid, folder = argv[0], Path(argv[1])
    p = PLACEMENTS[pid]
    errs, warns = [], []
    if (folder / "animate").is_dir():
        motion = argv[argv.index("--motion") + 1] if "--motion" in argv else "1.3.1"
        check_animate(folder / "animate", errs, warns, motion)
        for w in warns:
            print("WARN ", w)
        for e in errs:
            print("FAIL ", e)
        print("PASS" if not errs else f"{len(errs)} problem(s)")
        return 1 if errs else 0
    if not p.get("verified"):
        errs.append(f"{pid} limits are unverified; confirm the spec before uploading")
    known = set(p["components"])
    for sub in folder.iterdir():
        if sub.is_dir() and sub.name not in known:
            warns.append(f"folder '{sub.name}' is not a component of {pid} ({', '.join(known)})")
    for key, c in p["components"].items():
        check_component(key, c, folder / key, errs, warns)
    if "--copy" in argv and p.get("copy"):
        check_copy(DATA["copy_rules"][p["copy"]], argv[argv.index("--copy") + 1], errs)
    for w in warns:
        print("WARN ", w)
    for e in errs:
        print("FAIL ", e)
    print("PASS" if not errs else f"{len(errs)} problem(s)")
    return 1 if errs else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.exit(main(sys.argv[1:]))
