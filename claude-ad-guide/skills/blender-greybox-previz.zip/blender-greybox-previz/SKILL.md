---
name: blender-greybox-previz
description: Build greybox (white-model) previz in Blender via the MCP bridge — camera paths, easing, and pixel-accurate composition — to feed as video reference into AI video tools like Kling, Runway or Veo. Use this whenever the user is working on previz, greybox, blockout, 白模, 運鏡稿, camera blocking, or a camera move they need to match against a KV / storyboard / reference frame; also use it for any Blender scripting task that involves placing a camera or a character to hit a specific on-screen percentage, setting up ease-in/ease-out on a camera, or rendering a grey untextured reference clip. Reach for it even when the user just says "make me a reference video for the camera move" without naming Blender.
---

# Blender 白模 previz

用 Blender 搭一支灰白示意影片，當成 AI 影片工具的 video reference。白模只負責
**空間、機位、速度**；材質、光線、長相交給 AI。

這份 SOP 是從一個真實專案（9:16、5 秒、三顆定格鏡頭）的踩坑紀錄整理出來的。
裡面每一條「不要這樣做」都對應一次重做。

## 先判斷要不要做

**該做**：運鏡有幾何邏輯（穿越／環繞／上下切換）、兩顆鏡頭要像素級同機位、
構圖要對齊既有 KV 的百分比、需要精確的加減速曲線。

**不該做**：固定機位、只要氛圍不要精準、轉場是剪接不是運鏡。
這種情況直接在 prompt 裡寫 `slow dolly in` 比建白模快。

白模的成本幾乎都在「建立 → 驗證 → 修正」的迴圈上，所以先問清楚精度需求再動手。
如果使用者的需求聽起來屬於「不該做」那一欄，先講出來再問要不要繼續，
不要默默花兩小時做一支用不到的東西。

## 環境前提

透過 **Blender 官方 MCP**（`blender.org/lab/mcp-server`）操作，Blender 5.1+。
這個環境有幾個非標準行為，**動手前先讀 `references/blender-mcp-gotchas.md`**，
不然大概率會在前十分鐘卡住（沒有 `context.active_object`、某些 operator 被沙箱擋、
action 的 fcurves 在新版換了存取路徑）。

## 八步流程

1. **先分析參考素材，不要先開 Blender。** 把 KV 疊上百分比格線，量出主體橫向中心在幾 %、
   頭部縱向 band、前景從幾 % 開始、天花板佔幾 %。這組數字是後面反解的目標值。
   用 `scripts/grid_compare.py` 的 `grid()`。

2. **驗證參考素材在物理上做不做得到。** KV 常常是合成稿，人物被單獨縮放過。
   用角尺寸算一次：焦段 f、主體距離 d，能不能同時滿足所有觀察到的百分比？
   **算出做不到就不要硬幹**，三選一：保主體犧牲環境（長焦）、保環境犧牲主體（廣角）、
   或像合成稿一樣把角色等比放大。第三條對 AI 完全沒影響——它讀構圖不讀物理。
   跳過這一步的代價是在長焦與廣角之間來回改十次還對不上。

3. **先定攝影機約束，再建場景。** 動不動？動哪個軸？允不允許轉向？焦段？幾個定格、各停多久？
   **焦段定案後不要輕易改**——改焦段等於整個場景重算（房間尺寸、天花板高度、所有物件位置）。
   9:16 有個垂直 FOV 陷阱，`references/blender-mcp-gotchas.md` 有對照表，
   32mm 在直式是 90° 垂直視角，會明顯魚眼。

4. **建場景**：真實尺度，一個 unit cube mesh 重複使用靠 scale 變形。
   畫面裡有人就用指定的 IK Rig，不要用方塊人——方塊人會讓 AI 生出比例怪異的人。
   見 `references/character-rig.md`。

5. **用投影反解物件位置，不要用眼睛擺。** 這是整套流程最重要的一步。
   見 `references/projection-solving.md`。

6. **渲驗證幀，跟參考圖並排疊格線比對。** 不要只看白模自己。
   用 `scripts/grid_compare.py` 的 `compare()`。

7. **輸出 PNG 序列 + 外部 ffmpeg 編碼。** 不要用 Blender 內建的 FFMPEG 輸出。

8. **寫一份規格 README 跟 .blend 放一起。** 焦段、sensor 設定、攝影機 euler、
   各定格的 frame 與高度、easing 設法、pose 參數、踩過的坑。
   三週後的自己不會記得為什麼 `rot_z` 是 180。

## 三條鐵律

這三件事各自對應一次整支重做，值得單獨拉出來。

**一、構圖用算的，不要用看的。**
在小縮圖上判斷「人好像太偏右」幾乎一定是錯的。要知道某個東西落在畫面的百分之幾，
就用 `world_to_camera_view` 投影出來看數字。有數字就不用吵構圖對不對。

**二、每次改完場景都跑一次擋鏡頭檢查。**
道具離攝影機 1m 以內會變成糊掉的巨大灰塊擋住整個畫面，而且在縮圖上不一定看得出來。
`near_camera()` 跑十秒，能省掉一輪重渲。

**三、設完 easing 一定要 `fc.update()`。**
設了 interpolation 和 handle type 但沒有 update，handle 不會重算，
實際跑出來是線性等速——客戶一眼就看得出「沒有加減速」。

## 產出什麼

一支白模交付四件：`mp4`、`.blend`（存版本號，舊版不要覆蓋）、PNG 序列、規格 README。
規格 README 最容易被省略，也最重要——有了它，下一支可以直接沿用同一組機位參數，
而「同一組機位」正是系列廣告看起來是一家人的原因。

## 交給 AI 影片工具的時候

白模是**輸入資料**，AI 不會腦補，它會照單全收：灰白材質可能被當成畫面內容、
無臉人偶可能真的生成出無臉的人、方塊道具可能真的變成方塊。所以 prompt 裡要明講：

> video reference 只提供攝影機運動與空間關係，灰白材質、無臉人偶、方塊道具
> 一律不得出現在成品畫面中

negative prompt 加上：
`greybox, low-poly, blockout geometry, clay render, grey untextured mannequin, faceless figure`

**還有一件事要提早確認**：不是每個 AI 影片工具都真的會照著參考影片的運鏡跑。
投入時間之前先用一支簡單的白模做對照組測一次。如果確認不吃運鏡，白模仍然有價值
（可以當運鏡對稿讓後期手工做，或當分鏡的構圖依據），但那是另一條路線，要提早知道。

## 參考資料

| 檔案 | 什麼時候讀 |
|---|---|
| `references/blender-mcp-gotchas.md` | **動手前必讀。** MCP 環境的非標準行為、攝影機朝向、easing、渲染與輸出設定 |
| `references/projection-solving.md` | 要擺物件位置、或要驗證構圖百分比的時候 |
| `references/character-rig.md` | 畫面裡有人的時候。含已驗證可用的 pose 參數 |
| `references/failure-modes.md` | 卡住的時候查症狀；收工前當檢查清單用 |
| `scripts/previz_lib.py` | 送進 Blender 的函式庫（見下） |
| `scripts/scene_template.py` | 新場景的起手式，改參數就能跑 |
| `scripts/grid_compare.py` | 在本機跑（不是 Blender 裡），疊格線與並排比對 |

## 怎麼用這些 script

`previz_lib.py` 和 `scene_template.py` 是**要在 Blender 裡面跑的**，而 MCP 是把
程式碼當字串送進去執行的，所以沒辦法 `import`。做法是把 `previz_lib.py` 的內容
讀出來，當成前導碼接在你要跑的程式前面一起送。

`grid_compare.py` 相反，它用 PIL 處理圖片，在本機環境直接跑就好。
