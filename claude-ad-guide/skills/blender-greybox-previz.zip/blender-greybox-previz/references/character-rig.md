# 角色：一律使用指定的 IK Rig

## 規則

**凡是 previz 裡出現人，一律使用 `KneeElbow IK Rig for BodyChanBodyKun.blend`。**
不要用方塊人、不要臨時找別的人偶、不要自己搭。

理由：

- **比例正確**（約 1.72m），AI 讀到的人體比例才不會歪。方塊人會讓 AI 生出比例怪異的人
- **完整 Rigify IK**，坐姿、站姿、舉手、握持道具都能精確擺，而且可重現
- 男女各一套，同一個視覺語言
- 跨專案一致，**累積下來的 pose 參數可以直接複用**

唯一例外：完全被裁切在畫面外的背景人物，用方塊代替就好。

## 拿到檔案

**這個 .blend 沒有包在 skill 裡**（2.57 MB，而且每個專案要自己版控一份）。
從白模教學網站的第 12 章下載，或跟團隊要。

**檔案管理**：下載之後複製一份到 `<專案>/blender_ref/` 一起版控，
**不要 link 外部路徑**——換機器會斷連。

如果使用者還沒把檔案放進專案，**先問路徑再開始**，
不要自己用方塊人代替然後做完才說——那樣整支要重做。

## 檔案內容

| 項目 | 名稱 |
|---|---|
| Collection | `bodykun`（男）／`bodychan`（女） |
| Armature | `bodykun-rig`／`bodychan-rig`（Rigify，583 根骨） |
| 現成 action | `bodykun-crawl-loop`、`bodychan-seiza-sit`、`bodychan-bodyik-pose` |
| 角色高度 | 約 1.72m（head bone 在 z = 1.607） |

網格已 parent 到 armature，**移動 rig 物件網格會跟著走**，不用個別搬。

## 匯入（每個角色需要一份獨立副本）

```python
P = r"<專案>\blender_ref\KneeElbow IK Rig for BodyChanBodyKun.blend"

# 要 N 個角色就 append N 次，每次產生 .001 / .002 ... 的獨立副本
N = 3
for _ in range(N):
    with bpy.data.libraries.load(P, link=False) as (src, dst):
        dst.collections = ["bodykun"]

# ⚠ append 會一併帶進 "bodykun-body" 巢狀 collection，而且它會被單獨 link 到
#   scene，造成重複。必須過濾掉。
rig_colls = sorted([c.name for c in bpy.data.collections
                    if c.name.startswith("bodykun")
                    and "-body" not in c.name
                    and not c.name.startswith("WGTS")])

for cn in rig_colls:
    c = bpy.data.collections[cn]
    if c.name not in [ch.name for ch in scene.collection.children]:
        scene.collection.children.link(c)

# 解除重複 link 的 -body 子集合
for cn in [c.name for c in bpy.data.collections if "-body" in c.name]:
    c = bpy.data.collections[cn]
    if c.name in [ch.name for ch in scene.collection.children]:
        scene.collection.children.unlink(c)

rigs = sorted([o.name for o in bpy.data.objects
               if o.type == 'ARMATURE' and o.name.startswith("bodykun-rig")])
```

## 三個座標陷阱（每次都會踩，先看這裡）

1. **角色面向 LOCAL −Y。** 要他面向鏡頭（鏡頭在 +Y 看 −Y）就 `rot_z = 180°`；
   背對鏡頭則 `rot_z = 0°`。
2. **`.L` 骨骼在 LOCAL +X**，不是直覺的 −X。
3. **設 IK 目標一定要用骨架區域座標。** 用世界座標的話，角色一旦轉了 180°
   左右就會顛倒，**手臂會交叉在胸前**。這個踩過，改兩次才發現。

確認 IK 有開（Rigify 預設是開的，但值得檢查）：

```python
rig.pose.bones["thigh_parent.L"]["IK_FK"]      # 0 = IK, 1 = FK
rig.pose.bones["upper_arm_parent.L"]["IK_FK"]
```

## 擺 pose

```python
def put_local(rig, bone_name, local_co):
    """用骨架區域座標放置 IK 目標。設 pb.matrix 是最省事的做法。"""
    pb = rig.pose.bones.get(bone_name)
    if not pb:
        return
    M = pb.matrix.copy()
    M.translation = Vector(local_co)
    pb.matrix = M
    bpy.context.view_layer.update()     # 每設一根就更新，後面的骨才算得對


def place(rig, loc, rz_deg, scale=1.0):
    rig.location = loc
    rig.rotation_euler = (0, 0, math.radians(rz_deg))
    rig.scale = (scale, scale, scale)
    bpy.context.view_layer.update()
```

### 已驗證可用的 pose 參數（scale 1.0 基準，區域座標）

坐姿．雙手放桌面：

```python
put_local(rig, "torso",     (0.00,  0.02, 0.54))
put_local(rig, "foot_ik.L", ( 0.18, -0.46, 0.06))
put_local(rig, "foot_ik.R", (-0.18, -0.46, 0.06))
put_local(rig, "hand_ik.L", ( 0.13, -0.42, 0.62))
put_local(rig, "hand_ik.R", (-0.13, -0.42, 0.62))
```

站姿．刷牙（右手舉到嘴邊）：

```python
put_local(rig, "torso",     (0.00, -0.05, 0.97))
put_local(rig, "foot_ik.L", ( 0.16,  0.00, 0.06))
put_local(rig, "foot_ik.R", (-0.16,  0.00, 0.06))
put_local(rig, "hand_ik.R", (-0.12, -0.20, 1.48))
put_local(rig, "hand_ik.L", ( 0.26,  0.06, 0.94))
```

**手不要伸太前面。** 曾經把 `hand_ik` 的 y 設到 −0.76（往前伸 1.14m），
手掌跑到距離鏡頭 0.9m、橫跨到畫面外。桌面遠緣大約在 −0.42，那是安全值。

## 縮放

`put_local` 的座標在骨架空間，**會隨物件 scale 一起縮放**，
所以整體放大時 pose 不用重調，直接改 `rig.scale`。

但**場景要跟著乘同一個係數**：

```python
SCALE = 1.5
seat_top  = 0.46 * SCALE     # 椅面高度
table_top = 0.62 * SCALE     # 桌面高度 = 手的高度
```

為了對齊 KV 的合成比例把角色放大到 1.5 倍時，桌子與椅子的高度必須一起乘 1.5，
否則手會浮在桌面上方。

## 換頭與掛道具

隱藏某個網格部件來換頭（例如換成食物方塊）：

```python
h = bpy.data.objects.get("bodykun-head")
if h:
    h.hide_render = True
    h.hide_viewport = True
```

道具要對齊到手上或頭上時，**先擺完 pose 再讀骨頭的世界座標**：

```python
bpy.context.view_layer.update()
hand_w = rig.matrix_world @ rig.pose.bones["hand_ik.R"].head
box("brush", (0.30, 0.10, 0.08), (hand_w.x, hand_w.y - 0.08, hand_w.z + 0.02))

head_w = rig.matrix_world @ rig.pose.bones["head"].head
box("food_cube", (0.62, 0.62, 0.86), (head_w.x, head_w.y, head_w.z + 0.16))
```

## 效能與取捨

一個 rig 583 根骨，七個角色會讓場景變重（實測 1463 個物件）。
Workbench 仍然跑得動，但要注意：

- **只放需要的角色。** 完全被裁切在畫面外的背景人物，用方塊代替
- **主體一定要用 rig。** 主角、以及任何會被 AI 拿去讀姿態的角色，都不能省
- 存檔會變大（實測 4.6MB），屬正常
