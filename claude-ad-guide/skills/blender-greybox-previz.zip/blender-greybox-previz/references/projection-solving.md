# 投影反解：用算的擺位置

整套流程最重要的一步。眼睛在縮圖上判斷構圖會嚴重誤判——曾經連續看錯三次，
改了半天，最後用 `world_to_camera_view` 一算，發現原本的位置早就是對的。

## 原理

`world_to_camera_view`（以下簡稱 `w2c`）把一個世界座標點投影到畫面座標，
回傳的 `.x` `.y` 都是 0–1。

關鍵性質：**對固定的 y、z，畫面 x 對世界 x 是線性關係**。
所以只要取兩個樣本點就能反解出「要落在指定百分比，世界座標該是多少」。
不需要迭代逼近，兩次投影就解出來了。

注意 `w2c` 的 `.y` 是**由下往上**（0 = 畫面底），
而人講構圖習慣由上往下，所以換算成「上 %」要用 `1 - p.y`。

## 反解 X

```python
def solve_x(scene, cam, y, z, frame, target_fx):
    """回傳能讓物件中心落在畫面 target_fx（0=左 1=右）的世界 X"""
    scene.frame_set(frame)
    bpy.context.view_layer.update()
    f0 = w2c(scene, cam, Vector((-1.0, y, z))).x
    f1 = w2c(scene, cam, Vector(( 1.0, y, z))).x
    return -1.0 + (target_fx - f0) * 2.0 / (f1 - f0)
```

## 反解 Z

```python
def solve_z(scene, cam, x, y, frame, target_fy):
    """target_fy 0=畫面頂 1=畫面底"""
    scene.frame_set(frame)
    bpy.context.view_layer.update()
    g0 = 1.0 - w2c(scene, cam, Vector((x, y, 0.0))).y
    g1 = 1.0 - w2c(scene, cam, Vector((x, y, 2.0))).y
    return 0.0 + (target_fy - g0) * 2.0 / (g1 - g0)
```

## 驗證：每次改完都跑

```python
def pj(scene, cam, co, frame):
    """回傳 (左%, 上%)"""
    scene.frame_set(frame)
    bpy.context.view_layer.update()
    p = w2c(scene, cam, Vector(co))
    return round(p.x * 100, 1), round((1 - p.y) * 100, 1)
```

實際專案收斂後的數字長這樣（目標 vs 實測）：

| 項目 | KV 目標 | 實測 |
|---|---|---|
| 食物方塊頭橫向 | 52–78% | 51.6–78.4% |
| 食物方塊頭縱向 | 18–45% | 18.0–45.0% |
| 男主中心橫向 | 50%（正中） | 50.0% |
| 兩位同事頭部 | 約 10% / 90% | 11.2% / 88.8% |
| 天花板 band | 8% | 6.0% |

**有了這組數字就不用吵構圖對不對，看數字就好。** 對不上也很好講，
差多少、往哪邊差，一目了然。

## 擋鏡頭檢查

跟反解一樣重要，而且更便宜。道具離鏡頭 1m 以內會變成糊掉的巨大灰塊擋住畫面，
在縮圖上不一定看得出來。

```python
camp = cam.matrix_world.translation
near = []
for o in bpy.data.objects:
    if o.type != 'MESH' or o.hide_render:
        continue
    bb = [o.matrix_world @ Vector(c) for c in o.bound_box]
    d = min((camp - p).length for p in bb)
    if d < 1.0:
        near.append((round(d, 2), o.name))
near.sort()
print(near)   # 正常只該剩下角色自己的手臂
```

曾經有四個道具距離鏡頭只有 0.50–0.76m，投影出去橫跨畫面 −63% 到 184%。
**這個檢查十秒鐘，能省掉一輪重渲。**

`scripts/previz_lib.py` 裡的 `near_camera()` 就是這個，記得每次改完場景就跑。
