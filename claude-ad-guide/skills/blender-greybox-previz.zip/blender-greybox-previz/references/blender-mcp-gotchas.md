# Blender 5.x + MCP 環境的技術陷阱

動手前讀這一份。這裡每一條都是實際卡住過的。

## 目錄

- [1. 沙箱擋掉的 operator](#1-沙箱擋掉的-operator)
- [2. 沒有 context.active_object](#2-沒有-contextactive_object)
- [3. Blender 4.4+ 的 slotted action](#3-blender-44-的-slotted-action)
- [4. 攝影機朝向（最容易錯）](#4-攝影機朝向最容易錯)
- [5. 9:16 的焦段陷阱](#5-916-的焦段陷阱)
- [6. Easing 一定要 fc.update()](#6-easing-一定要-fcupdate)
- [7. 渲染設定：Workbench](#7-渲染設定workbench)
- [8. 輸出](#8-輸出)

---

## 1. 沙箱擋掉的 operator

```python
# ✗ 被擋
bpy.ops.wm.read_factory_settings(use_empty=True)

# ✓ 用這個
bpy.ops.wm.read_homefile(use_empty=True, use_factory_startup=True)
```

## 2. 沒有 context.active_object

MCP 執行環境沒有正常的 UI context，`bpy.ops.mesh.primitive_cube_add()` 之後
`bpy.context.active_object` 會是 `None`。

**所有建物件的動作都改用 `bpy.data` API。** 除了能在這個環境跑之外，
還比較快也比較輕——一個 unit cube mesh 重複使用，靠 scale 變形就好。
`scripts/previz_lib.py` 裡的 `box()` 就是這個做法。

## 3. Blender 4.4+ 的 slotted action

`action.fcurves` 在新版可能不存在，要走 layers → strips → channelbags。
`previz_lib.py` 的 `all_fcurves()` 已經處理了兩種情況，直接用它。

```python
def all_fcurves(ob):
    act = ob.animation_data.action
    if hasattr(act, "fcurves") and len(act.fcurves):
        return list(act.fcurves)
    return [fc for L in act.layers for s in L.strips
            for cb in s.channelbags for fc in cb.fcurves]
```

## 4. 攝影機朝向（最容易錯）

**攝影機看向自己的 local −Z，up 是 local +Y。**

| rotation_euler | 看向 | up | 結果 |
|---|---|---|---|
| `(-90°, 0, 0)` | −Y | **−Z** | **整個畫面上下顛倒** |
| `(90°, 0, 0)` | +Y | +Z | 方向相反 |
| `(90°, 0, 180°)` | **−Y** | **+Z** | **正確** |

第一列踩過：整支片是倒的，人頭在下面。

**連帶的座標陷阱**：`rot_z = 180°` 表示**世界 +X 會投影到畫面「左」邊**。
放道具時憑直覺一定會左右放反，所以每次都驗一下：

```python
for x in (-1.0, 1.0):
    print(x, round(w2c(scene, cam, Vector((x, y, z))).x, 3))
# world_x = -1.0 → 0.934（畫面右）
# world_x = +1.0 → 0.066（畫面左）
```

## 5. 9:16 的焦段陷阱

Blender 的 `sensor_fit` 預設會讓人算錯垂直 FOV：

```
sensor_fit = 'HORIZONTAL', sensor_width = 36mm, 解析度 720×1280
→ 等效垂直 sensor = 36 × (1280/720) = 64mm
→ 垂直 FOV = 2 × atan(32 / f)
```

| 焦段 | 垂直 FOV | 感受 |
|---|---|---|
| 32mm | 90° | 超廣角，明顯魚眼變形 |
| 40mm | 77° | 偏廣 |
| 49mm | 66° | 接近正常手機直拍 |
| 55mm | 60° | 略窄，容易把配角切出畫面 |

直式畫面同樣焦段的視角會比橫式大很多，所以橫式的直覺在這裡不適用。
改焦段會連帶影響房間尺寸：曾經從 32mm 改到 49mm，房間淨高就得從 3.6m 降到 2.87m，
才能把天花板 band 壓回 6%。

## 6. Easing 一定要 fc.update()

設了 interpolation 和 handle type **但沒有 update，handle 不會重算**，
實際跑出來是線性等速。

```python
for fc in all_fcurves(cam):
    kps = sorted(fc.keyframe_points, key=lambda k: k.co[0])
    for i, kp in enumerate(kps):
        nxt = kps[i + 1] if i + 1 < len(kps) else None
        if nxt and abs(nxt.co[1] - kp.co[1]) > 1e-6:
            kp.interpolation = 'CUBIC'       # 有位移的段落
            kp.easing = 'EASE_IN_OUT'
        else:
            kp.interpolation = 'LINEAR'      # 定格段落，值相同，線性即可
    fc.update()                              # ← 這行不能少
```

**驗證方式**：印出每兩幀的位移量，應該是慢→快→慢的對稱曲線。

```
每格位移：0 → 0.014 → 0.10 → 0.27 → 0.53 → 0.87 → 1.18 → 0.87 → 0.53 → 0.27 → 0.10 → 0
```

`previz_lib.py` 的 `apply_easing()` 和 `dump_deltas()` 就是這兩件事。

## 7. 渲染設定：Workbench

Workbench 是白模的正解：快、乾淨、不用打光，而且 cavity + outline 讓形體邊界清楚——
這正是 AI 需要讀到的資訊。

```python
scene.render.engine = 'BLENDER_WORKBENCH'
sh = scene.display.shading
sh.light = 'STUDIO'
sh.color_type = 'SINGLE'
sh.single_color = (0.82, 0.82, 0.82)
sh.show_cavity = True
sh.cavity_type = 'BOTH'
sh.curvature_ridge_factor = 1.4
sh.curvature_valley_factor = 1.4
sh.show_shadows = True
sh.shadow_intensity = 0.20
sh.show_object_outline = True
sh.object_outline_color = (0.25, 0.25, 0.25)
scene.display.render_aa = '8'
scene.view_settings.view_transform = 'Standard'

if scene.world is None:
    scene.world = bpy.data.worlds.new("REF_WORLD")
scene.world.color = (0.55, 0.55, 0.55)   # 留全黑會被讀成破洞
```

## 8. 輸出

```python
# ✗ 某些 build（含 Blender 5.2）的 file_format enum 裡沒有 'FFMPEG'
scene.render.image_settings.file_format = 'FFMPEG'

# ✓ PNG 序列 + 外部 ffmpeg
scene.render.image_settings.file_format = 'PNG'
scene.render.image_settings.color_mode = 'RGB'
scene.render.image_settings.compression = 30
scene.render.filepath = os.path.join(OUT, "seq_v1", "f_")
scene.frame_start, scene.frame_end = 1, 120
bpy.ops.render.render(animation=True)
```

```bash
ffmpeg -y -framerate 24 -start_number 1 -i seq_v1/f_%04d.png \
       -c:v libx264 -pix_fmt yuv420p -crf 17 -movflags +faststart out.mp4
```
