"""疊百分比格線、並排比對 —— 在本機跑，不是在 Blender 裡跑。

兩個用途：
  1. 開工前：把 KV 疊上格線，量出關鍵物件的百分比（那是後面反解的目標值）
  2. 每次改完：把驗證幀跟 KV 並排，兩邊都疊格線，才看得出差多少

只需要 pillow。
"""

import sys

from PIL import Image, ImageDraw

RED = (255, 0, 0)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)
GREEN = (0, 255, 0)


def grid(path, label=None, size=(360, 640), step=10, verticals=(25, 50, 75)):
    """回傳疊好格線的圖。水平線每 step%，垂直線在 verticals 指定的百分比。"""
    im = Image.open(path).convert("RGB").resize(size)
    w, h = size
    d = ImageDraw.Draw(im)
    for p in range(step, 100, step):
        y = int(h * p / 100)
        d.line([(0, y), (w, y)], fill=RED)
        d.text((3, y - 11), str(p), fill=YELLOW)
    for p in verticals:
        x = int(w * p / 100)
        d.line([(x, 0), (x, h)], fill=CYAN)
    if label:
        d.rectangle([0, 0, 90, 16], fill=(0, 0, 0))
        d.text((3, 3), label, fill=GREEN)
    return im


def compare(ref_path, shot_path, out_path, size=(360, 640),
            ref_label="KV", shot_label="GREYBOX"):
    """把參考圖和白模驗證幀並排存成一張，兩邊都疊格線。

    不要只看白模自己 —— 並排才看得出「差 3%」這種等級的偏移。
    """
    w, h = size
    m = Image.new("RGB", (w * 2, h), "white")
    m.paste(grid(ref_path, ref_label, size), (0, 0))
    m.paste(grid(shot_path, shot_label, size), (w, 0))
    m.save(out_path)
    return out_path


if __name__ == "__main__":
    if len(sys.argv) == 3:
        # 一張圖：疊格線
        print(grid(sys.argv[1]).save(sys.argv[2]) or sys.argv[2])
    elif len(sys.argv) == 4:
        # 兩張圖：並排比對
        print(compare(sys.argv[1], sys.argv[2], sys.argv[3]))
    else:
        print(__doc__)
        print("用法：")
        print("  python grid_compare.py KV.jpg KV_grid.png")
        print("  python grid_compare.py KV.jpg render_110.png compare.png")
