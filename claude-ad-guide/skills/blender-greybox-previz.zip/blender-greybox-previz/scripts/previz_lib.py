"""白模 previz 的函式庫 —— 在 Blender 裡面跑。

MCP 是把程式碼當字串送進 Blender 執行的，沒辦法 import。所以用法是：
把這個檔案的內容讀出來，接在你要跑的程式前面一起送進去。

    lib = open("scripts/previz_lib.py", encoding="utf-8").read()
    send_code(lib + "\n\n" + your_code)

每個函式都假設 bpy / math / Vector / w2c 已經由下面的 import 準備好。
"""

import math
import os

import bpy
from bpy_extras.object_utils import world_to_camera_view as w2c
from mathutils import Vector

# --------------------------------------------------------------------------
# 建場景
# --------------------------------------------------------------------------

_UNIT_CUBE_VERTS = [
    (-.5, -.5, -.5), (.5, -.5, -.5), (.5, .5, -.5), (-.5, .5, -.5),
    (-.5, -.5, .5), (.5, -.5, .5), (.5, .5, .5), (-.5, .5, .5),
]
_UNIT_CUBE_FACES = [
    (0, 1, 2, 3), (4, 7, 6, 5), (0, 4, 5, 1),
    (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0),
]


def unit_cube():
    """共用的 unit cube mesh。所有方塊共用同一份 mesh，靠 scale 變形。"""
    m = bpy.data.meshes.get("unit_cube")
    if m is None:
        m = bpy.data.meshes.new("unit_cube")
        m.from_pydata(_UNIT_CUBE_VERTS, [], _UNIT_CUBE_FACES)
        m.update()
    return m


def box(name, size, loc, rz=0.0, collection=None):
    """建立（或更新）一個方塊。

    用 bpy.data 而不是 bpy.ops —— MCP 環境沒有正常的 UI context，
    bpy.ops.mesh.primitive_cube_add() 之後 context.active_object 會是 None。
    """
    coll = collection or bpy.context.scene.collection
    ob = bpy.data.objects.get(name)
    if ob is None:
        ob = bpy.data.objects.new(name, unit_cube())
        coll.objects.link(ob)
    ob.scale = size
    ob.location = loc
    ob.rotation_euler = (0, 0, rz)
    return ob


# --------------------------------------------------------------------------
# 攝影機
# --------------------------------------------------------------------------

def make_camera(name="CAM_REF", lens=49.0, sensor_width=36.0, clip_start=0.02):
    """建立朝 −Y、+Z 為上的攝影機。

    攝影機看向 local −Z、up 是 local +Y，所以 (90°, 0, 180°) 才是正的。
    (-90°, 0, 0) 會讓整個畫面上下顛倒 —— 這是最常踩的一個坑。
    """
    scene = bpy.context.scene
    cd = bpy.data.cameras.new(name)
    cd.lens = lens
    cd.sensor_fit = 'HORIZONTAL'
    cd.sensor_width = sensor_width
    cd.clip_start = clip_start
    cam = bpy.data.objects.new(name, cd)
    scene.collection.objects.link(cam)
    scene.camera = cam
    cam.rotation_euler = (math.radians(90), 0.0, math.radians(180))
    return cam


def vertical_fov(lens, sensor_width=36.0, res_x=720, res_y=1280):
    """直式畫面的垂直 FOV（度）。

    sensor_fit='HORIZONTAL' 時等效垂直 sensor = sensor_width * res_y / res_x，
    所以直式的垂直視角會比橫式的直覺大很多。32mm 在 9:16 是 90°，會明顯魚眼。
    """
    eq = sensor_width * res_y / res_x
    return math.degrees(2 * math.atan((eq / 2) / lens))


# --------------------------------------------------------------------------
# 投影反解與驗證
# --------------------------------------------------------------------------

def solve_x(y, z, frame, target_fx, scene=None, cam=None):
    """回傳能讓物件中心落在畫面 target_fx（0=左 1=右）的世界 X。

    對固定的 y、z，畫面 x 對世界 x 是線性的，所以兩個樣本點就解得出來。
    """
    scene = scene or bpy.context.scene
    cam = cam or scene.camera
    scene.frame_set(frame)
    bpy.context.view_layer.update()
    f0 = w2c(scene, cam, Vector((-1.0, y, z))).x
    f1 = w2c(scene, cam, Vector((1.0, y, z))).x
    return -1.0 + (target_fx - f0) * 2.0 / (f1 - f0)


def solve_z(x, y, frame, target_fy, scene=None, cam=None):
    """回傳能讓物件中心落在畫面 target_fy（0=頂 1=底）的世界 Z。"""
    scene = scene or bpy.context.scene
    cam = cam or scene.camera
    scene.frame_set(frame)
    bpy.context.view_layer.update()
    g0 = 1.0 - w2c(scene, cam, Vector((x, y, 0.0))).y
    g1 = 1.0 - w2c(scene, cam, Vector((x, y, 2.0))).y
    return 0.0 + (target_fy - g0) * 2.0 / (g1 - g0)


def pj(co, frame, scene=None, cam=None):
    """把世界座標投影成 (左%, 上%)。改完場景就用這個驗，不要用眼睛看縮圖。"""
    scene = scene or bpy.context.scene
    cam = cam or scene.camera
    scene.frame_set(frame)
    bpy.context.view_layer.update()
    p = w2c(scene, cam, Vector(co))
    return round(p.x * 100, 1), round((1 - p.y) * 100, 1)


def check_axis(y, z, frame, scene=None, cam=None):
    """確認世界 X 的正負對應到畫面的哪一邊。

    rot_z=180° 時世界 +X 會投影到畫面「左」邊，憑直覺放道具一定會左右放反。
    """
    return {x: round(pj((x, y, z), frame, scene, cam)[0], 1) for x in (-1.0, 1.0)}


def near_camera(frame, limit=1.0, scene=None, cam=None):
    """列出距離攝影機 limit 公尺內的 mesh。正常只該剩下角色自己的手臂。

    離鏡頭 1m 內的道具會變成糊掉的巨大灰塊擋住整個畫面，而且縮圖上看不出來。
    這個檢查跑十秒，能省掉一輪重渲 —— 每次改完場景都跑。
    """
    scene = scene or bpy.context.scene
    cam = cam or scene.camera
    scene.frame_set(frame)
    bpy.context.view_layer.update()
    camp = cam.matrix_world.translation
    out = []
    for o in bpy.data.objects:
        if o.type != 'MESH' or o.hide_render:
            continue
        bb = [o.matrix_world @ Vector(c) for c in o.bound_box]
        d = min((camp - p).length for p in bb)
        if d < limit:
            out.append((round(d, 2), o.name))
    return sorted(out)


# --------------------------------------------------------------------------
# 動畫與 easing
# --------------------------------------------------------------------------

def all_fcurves(ob):
    """取得 fcurves，同時支援舊版與 Blender 4.4+ 的 slotted action。"""
    act = ob.animation_data.action
    if hasattr(act, "fcurves") and len(act.fcurves):
        return list(act.fcurves)
    return [fc for L in act.layers for s in L.strips
            for cb in s.channelbags for fc in cb.fcurves]


def apply_easing(ob):
    """有位移的段落用 CUBIC + EASE_IN_OUT，定格段落用 LINEAR。

    最後的 fc.update() 不能少 —— 沒有它 handle 不會重算，
    設了 interpolation 也還是線性等速。
    """
    for fc in all_fcurves(ob):
        kps = sorted(fc.keyframe_points, key=lambda k: k.co[0])
        for i, kp in enumerate(kps):
            nxt = kps[i + 1] if i + 1 < len(kps) else None
            if nxt and abs(nxt.co[1] - kp.co[1]) > 1e-6:
                kp.interpolation = 'CUBIC'
                kp.easing = 'EASE_IN_OUT'
            else:
                kp.interpolation = 'LINEAR'
        fc.update()


def dump_deltas(ob, f0, f1, axis=2, scene=None):
    """印出每格的位移量。正確的 easing 應該是慢→快→慢的對稱曲線。"""
    scene = scene or bpy.context.scene
    vals = []
    for f in range(f0, f1 + 1):
        scene.frame_set(f)
        bpy.context.view_layer.update()
        vals.append(ob.matrix_world.translation[axis])
    return [round(abs(vals[i + 1] - vals[i]), 3) for i in range(len(vals) - 1)]


# --------------------------------------------------------------------------
# 角色
# --------------------------------------------------------------------------

def put_local(rig, bone_name, local_co):
    """用骨架區域座標放置 IK 目標。

    一定要用區域座標 —— 用世界座標的話，角色轉 180° 之後左右會顛倒，
    手臂會交叉在胸前。
    """
    pb = rig.pose.bones.get(bone_name)
    if not pb:
        return
    M = pb.matrix.copy()
    M.translation = Vector(local_co)
    pb.matrix = M
    bpy.context.view_layer.update()


def place(rig, loc, rz_deg, scale=1.0):
    """擺放角色。面向鏡頭 rz_deg=180，背對鏡頭 rz_deg=0（角色面向 local −Y）。"""
    rig.location = loc
    rig.rotation_euler = (0, 0, math.radians(rz_deg))
    rig.scale = (scale, scale, scale)
    bpy.context.view_layer.update()


def bone_world(rig, bone_name):
    """讀骨頭的世界座標，用來把道具對齊到手上或頭上。先擺完 pose 再讀。"""
    bpy.context.view_layer.update()
    return rig.matrix_world @ rig.pose.bones[bone_name].head


# --------------------------------------------------------------------------
# 渲染
# --------------------------------------------------------------------------

def setup_workbench(res_x=720, res_y=1280, fps=24):
    """白模的標準渲染設定。

    Workbench 快、乾淨、不用打光，cavity + outline 讓形體邊界清楚 ——
    這正是 AI 需要讀到的資訊。
    """
    scene = bpy.context.scene
    scene.render.engine = 'BLENDER_WORKBENCH'
    sh = scene.display.shading
    sh.light = 'STUDIO'
    sh.color_type = 'SINGLE'
    sh.single_color = (0.82, 0.82, 0.82)
    sh.show_cavity = True
    sh.cavity_type = 'BOTH'
    sh.curvature_ridge_factor = 1.4
    sh.curvature_valley_factor = 1.4
    sh.show_shadows = True
    sh.shadow_intensity = 0.20
    sh.show_object_outline = True
    sh.object_outline_color = (0.25, 0.25, 0.25)
    scene.display.render_aa = '8'
    scene.view_settings.view_transform = 'Standard'
    scene.render.resolution_x = res_x
    scene.render.resolution_y = res_y
    scene.render.fps = fps
    if scene.world is None:
        scene.world = bpy.data.worlds.new("REF_WORLD")
    scene.world.color = (0.55, 0.55, 0.55)   # 留全黑會被讀成破洞
    return scene


def render_checks(out_dir, frames):
    """渲幾張驗證幀出來，拿去跟參考圖並排比對。"""
    scene = bpy.context.scene
    os.makedirs(out_dir, exist_ok=True)
    scene.render.image_settings.file_format = 'PNG'
    paths = []
    for f in frames:
        scene.frame_set(f)
        scene.render.filepath = os.path.join(out_dir, "chk_{:03d}.png".format(f))
        bpy.ops.render.render(write_still=True)
        paths.append(scene.render.filepath)
    return paths


def render_sequence(out_dir, f_start, f_end):
    """輸出 PNG 序列。不要用 Blender 內建的 FFMPEG —— 某些 build 沒有那個選項。

    之後用外部 ffmpeg 編碼：
      ffmpeg -y -framerate 24 -start_number 1 -i f_%04d.png \\
             -c:v libx264 -pix_fmt yuv420p -crf 17 -movflags +faststart out.mp4
    """
    scene = bpy.context.scene
    os.makedirs(out_dir, exist_ok=True)
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGB'
    scene.render.image_settings.compression = 30
    scene.render.filepath = os.path.join(out_dir, "f_")
    scene.frame_start, scene.frame_end = f_start, f_end
    bpy.ops.render.render(animation=True)
    return out_dir
