"""新場景的起手式。改上面的參數就能跑。

跑法：把 previz_lib.py 的內容接在這個檔案前面，整段送進 Blender。
單獨送這個檔案會因為找不到 box() / make_camera() 等函式而失敗。
"""

# ---------- 0. 清空 ----------
# read_factory_settings 會被沙箱擋掉，用 read_homefile
bpy.ops.wm.read_homefile(use_empty=True, use_factory_startup=True)
scene = bpy.context.scene
vl = bpy.context.view_layer
coll = scene.collection

# ---------- 1. 參數集中在最上面 ----------
LENS = 49.0                                  # 改這個要連帶重算空間尺寸
CAM_XY = (0.0, 0.90)
FPS = 24
TOTAL_F = 120
RES = (720, 1280)                            # 9:16
HOLDS = [(1, 30), (52, 74), (96, 120)]       # 各定格的 frame 區間
HOLD_Z = [10.89, 6.16, 1.29]                 # 各定格的攝影機高度
OUT = r"C:\path\to\output"

print("垂直 FOV:", round(vertical_fov(LENS, res_x=RES[0], res_y=RES[1]), 1), "度")

# ---------- 2. 建場景 ----------
# 真實尺度。所有方塊共用一份 unit cube mesh，靠 scale 變形。
# box("wall_back", (6.6, 0.22, 2.87), (0, -3.6, 1.435))
# box("floor",     (6.6, 7.2, 0.10),  (0, 0, -0.05))

# ---------- 3. 攝影機 ----------
cam = make_camera(lens=LENS)
scene.frame_start, scene.frame_end = 1, TOTAL_F

keys = []
for (a, b), z in zip(HOLDS, HOLD_Z):
    keys += [(a, z), (b, z)]
for f, z in keys:
    cam.location = (CAM_XY[0], CAM_XY[1], z)
    cam.keyframe_insert("location", frame=f)

# ---------- 4. Easing ----------
apply_easing(cam)
print("每格位移:", dump_deltas(cam, HOLDS[0][1], HOLDS[1][0]))   # 應該是慢快慢

# ---------- 5. 擺位置（用算的，不要用眼睛） ----------
# 例：把某個物件放到畫面橫向 43%、縱向 30%
# x = solve_x(y=-1.2, z=1.0, frame=15, target_fx=0.43)
# z = solve_z(x=x,    y=-1.2, frame=15, target_fy=0.30)

# ---------- 6. 渲染設定 ----------
setup_workbench(res_x=RES[0], res_y=RES[1], fps=FPS)

# ---------- 7. 驗證：這兩行每次改完場景都要跑 ----------
print("擋鏡頭:", near_camera(15))            # 正常只該剩角色自己的手臂
print("軸向:", check_axis(y=-1.2, z=1.0, frame=15))
# print("關鍵物件:", pj((0.0, -1.2, 1.0), 15))

# ---------- 8. 輸出驗證幀 ----------
# render_checks(OUT, (15, 41, 63, 85, 110))

# ---------- 9. 確認無誤之後才輸出整段序列 ----------
# render_sequence(os.path.join(OUT, "seq_v1"), 1, TOTAL_F)

result = {"status": "ok", "fov": round(vertical_fov(LENS, res_x=RES[0], res_y=RES[1]), 1)}
