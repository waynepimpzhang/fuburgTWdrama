"""Batch-generate music / SFX with Stable Audio 3 through audio-studio-mcp, without the MCP layer.

Usage (always with the audio-studio venv):
  C:\\tools\\audio-studio-mcp\\.venv\\Scripts\\python.exe sa3_jobs.py jobs.json OUT_DIR

jobs.json is a list of objects. Keys are generate_audio's parameters, plus "title":
  {"title": "A_suspense", "audio_type": "music", "prompt": "...", "duration_seconds": 10, "bpm": 70, "variations": 2, "seed": 7000}
  {"title": "gate", "audio_type": "sfx", "duration_seconds": 1.6, "sound_source": "...", "sound_action": "...",
   "sound_material": "...", "sound_space": "...", "variations": 2}
Writes <title>_v1.wav ... plus a .json sidecar each, and OUT_DIR/_batch_log.json with wall times.
"""
import asyncio
import json
import os
import sys
import time
from pathlib import Path


async def main(jobs_path: str, out_dir: str) -> None:
    out = Path(out_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    os.environ["AUDIO_STUDIO_OUTPUT_DIR"] = str(out)
    from audio_studio_mcp.server import generate_audio  # import after the env var is set

    jobs = json.loads(Path(jobs_path).read_text(encoding="utf-8"))
    log = []
    for job in jobs:
        t = time.perf_counter()
        r = await generate_audio(**job)
        wall = round(time.perf_counter() - t, 2)
        log.append({"title": job.get("title"), "wall": wall, "result": r})
        print(job.get("title"), wall, "s", [c.get("path") for c in r.get("candidates", [])], flush=True)
    (out / "_batch_log.json").write_text(json.dumps(log, ensure_ascii=False, indent=2, default=str), encoding="utf-8")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    asyncio.run(main(sys.argv[1], sys.argv[2]))
