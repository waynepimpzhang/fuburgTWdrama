---
name: audio-gen
description: Generate background music, songs and sound effects locally for video projects, with Stable Audio 3 (audio-studio-mcp) or MiniMax Music 3 (ComfyUI template). Use whenever the user asks for 配樂, BGM, 音效, SFX, stinger, ambience, a jingle, a song with lyrics, or wants music or sound for a video, ad or short; also when they mention audio-studio, Stable Audio or MiniMax Music. Picks the engine, writes the prompt in that engine's format, generates 2+ candidates and post-processes them for the edit.
---

# Local music and SFX generation

Both engines run on this PC's RTX 4090 and cost no credits. Run them without asking; only the paid ElevenLabs/partner API nodes in ComfyUI need the user's yes.

## Pick the engine

| Need | Engine | Why |
|---|---|---|
| Sound effect, ambience, foley, whoosh, one-shot | **Stable Audio 3** | Has an sfx mode with source/action/material/space fields. MiniMax has no SFX mode. |
| Song with vocals or lyrics | **MiniMax Music 3** | Stable Audio 3 cannot sing. |
| Instrumental BGM or stinger | Both, 2 takes each, let the user listen | MiniMax takes a long multi-part caption; SA3 prompts cap at ~45 words but run ~30× faster. Which sounds better is the user's call. |
| Many variations, loops, extend a cue, replace 2 seconds in the middle, loudness for delivery | **Stable Audio 3** | `edit_audio` (variation / inpaint / continue) and `process_audio` (loop, fades, LUFS, 48 kHz). |

Measured on this PC (2026-11-04): SA3 medium, 2 candidates of 10 s ≈ 1 s warm, ≈ 19 s with the first model load. MiniMax Music 3 fp16, 10 s ≈ 28–32 s, 5 s ≈ 13 s.

These rules came from a listening comparison on 2026-11-04.

## Stable Audio 3 (audio-studio-mcp)

Installed at `C:\tools\audio-studio-mcp`, registered as the user-scope MCP server `audio-studio`. Follow the prompt format in that server's instructions (already in context when the server is connected). When it is not connected, the short form is: English, ≤ ~45 words, no vocal words; tempo in `bpm`; SFX need `audio_type: "sfx"` plus the four `sound_*` fields; `variations: 2–4`. Beyond those instructions:

- Outputs are 44.1 kHz 24-bit WAV with a `.json` sidecar. Set the folder with env `AUDIO_STUDIO_OUTPUT_DIR`, or move the files after.
- Takes often start with 0.4–1.2 s of near-silence. For hits, run `process_audio` with `trim_silence: true`.
- For video delivery: `process_audio` with `normalize: "loudness"`, `target_lufs: -14`, `sample_rate: 48000`.

**Tools available** (MCP tools `generate_audio`, `edit_audio`, `process_audio`, `unload_models`): call them directly.

**Tools not loaded in this session** (or for a batch): use the script next to this file, which calls the same function without MCP:

```
C:\tools\audio-studio-mcp\.venv\Scripts\python.exe <skill>\scripts\sa3_jobs.py jobs.json OUT_DIR
```

`jobs.json` is a list of `generate_audio` keyword sets; see the script's docstring. Always use that venv's python.

The web UI is `C:\tools\audio-studio-mcp\.venv\Scripts\audio-studio-mcp.exe --web 8765`. It listens on 127.0.0.1 only; never expose it.

## MiniMax Music 3 (ComfyUI)

Use the comfy-mcp tools against the local ComfyUI (`server_info` first). The template is the free local `audio_minimax_music_3`, not an API node, and its models are already installed.

1. `fetch_template("audio_minimax_music_3", <project>\comfy\<name>.json)` and confirm `local_check.runnable`.
2. Run `list_workflow_slots` and confirm the node ids below still exist (they were read from the template on 2026-11-04 and change when the template is updated; if they differ, use the slots with the same input names). Then `set_workflow_slot(..., stdout=false)` with:
   - `37/13.caption`: three blocks, `Global Metadata:` (genre, BPM, key, mood, "Instrumental only, no vocals." when instrumental), then vocal details if singing, then `Arrangement:` (instruments, development, ending).
   - `37/13.lyrics`: `[Instrumental]` for BGM, or lyrics with `[intro] [verse] [chorus] [bridge] [outro]` tags. Only the tags drive structure.
   - `37/13.max_duration` **and** `37/15.seconds`: both set to the target length.
   - **`37/38.seed`**: this SeedNode is the seed that counts. Changing only `37/13.seed` / `37/9.seed` leaves the run fully cached and returns the old file.
   - `35.filename_prefix` (e.g. `audio_test/D_warm_mm_0`), `35.format` = `flac`.
3. `run_workflow` (`wait` is fine for ≤ 60 s clips). Output lands in `C:\ComfyUI_windows_portable\ComfyUI\output\<prefix>_00001.flac`. Copy it into the project.
4. One take per run. For 2 takes, copy the JSON and change `37/38.seed`.

MiniMax output can peak above 0 dBTP (seen +0.2 to +0.8). Normalize it with SA3's `process_audio` or ffmpeg before mixing.

## After generating

- Name files `<cue>_<engine>_<n>` (e.g. `B_sneaky_sa3_v1.wav`, `B_sneaky_mm_0.flac`) and never overwrite earlier takes.
- Measure before handing over: `ffmpeg -i f -af ebur128=peak=true -f null -` gives integrated LUFS and true peak.
- For more than a couple of takes, give the user a listening page (Artifact, mp3 files beside it, play button + waveform per take, a pick button, "複製選擇結果"). Start from `templates/listening-page.html` in this skill: copy it, fill the `__PLACEHOLDER__` texts and the five constants at the top of its script (`M`, `ENG`, `MUSIC`, `SFX`, `NOTES`), and publish it with the mp3s as `media/<cue id>_<take>.mp3`. Do not re-read the old comparison Artifact for the layout. The template has no `<meta charset>` because the Artifact wrapper adds one; to preview it as a local file, put `<!doctype html><meta charset="utf-8">` in front.
- The ElevenLabs node in ComfyUI (`ElevenLabsTextToSoundEffects`) is paid, and two runs with one prompt returned identical audio. Prefer SA3 for SFX.

## Licence (facts only; route commercial questions to legal)

- Stable Audio 3 weights: Stability AI Community License, free commercial use under 1,000,000 USD total annual revenue, Enterprise licence above that.
- MiniMax Music 3: the ComfyUI repack says apache-2.0, but the original model uses the MiniMax-Music3 Community License. Commercial use must display "MiniMax-Music3" in the product UI and needs written authorisation from MiniMax above 20,000,000 USD yearly revenue (incl. affiliates).
- Before client or Nasdaq-listed-company deliverables use these outputs, tell the user to have legal confirm. Do not state a final legal conclusion.
